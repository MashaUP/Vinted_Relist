/* Selezione multipla e pannello della coda. */
(() => {
  const VR = (window.VR = window.VR || {});
  const h = VR.h;

  // ---------------------------------------------------------------- selezione

  const selezionati = new Set();
  const caselle = new Map();           // id → input, per "tutti" e "deseleziona"


  let ultimoIndice = -1;

  /** Le caselle in ordine di pagina: l'intervallo dello shift-click e' questo. */
  const inOrdine = () => [...document.querySelectorAll(".vr-bar__pick")];

  VR.selection = {
    registra(id, input) {
      // Vinted ridisegna le card navigando: le caselle staccate vanno via.
      for (const [chiave, vecchia] of caselle) {
        if (!vecchia.isConnected) caselle.delete(chiave);
      }
      caselle.set(id, input);
      input.checked = selezionati.has(id);
    },
    cambia(id, acceso) {
      if (acceso) selezionati.add(id);
      else selezionati.delete(id);
      disegna();
    },
    /** Clic su una casella: con Shift estende dall'ultima toccata a questa. */
    clic(id, evento) {
      const input = evento.target;
      const elenco = inOrdine();
      const indice = elenco.indexOf(input);

      if (evento.shiftKey && ultimoIndice >= 0 && indice >= 0) {
        const da = Math.min(ultimoIndice, indice);
        const a = Math.max(ultimoIndice, indice);
        for (let k = da; k <= a; k++) {
          const casella = elenco[k];
          casella.checked = input.checked;
          const suo = casella.dataset.vrId;
          if (input.checked) selezionati.add(suo);
          else selezionati.delete(suo);
        }
      } else if (input.checked) {
        selezionati.add(id);
      } else {
        selezionati.delete(id);
      }

      ultimoIndice = indice;
      disegna();
    },
    tutti() {
      for (const [id, input] of caselle) {
        if (!input.isConnected) continue;
        input.checked = true;
        selezionati.add(id);
      }
      disegna();
    },
    nessuno() {
      for (const input of caselle.values()) {
        if (input.isConnected) input.checked = false;
      }
      selezionati.clear();
      ultimoIndice = -1;
      disegna();
    },
  };

  // ------------------------------------------------------------------ pannello

  let pannello = null;
  let coda = null;
  let tic = null;
  let controlloInCorso = false;

  /**
   * Opzioni della coda come le hai scritte nella finestra. Restano salvate tra
   * una sessione e l'altra; l'orario di avvio no, perche' scade.
   */
  const OPZIONI_VUOTE = {
    modo: "", valore: "", aggiunta: "", cerca: "", con: "", colore: "", quando: "", intervallo: "",
    modello: "",          // nome del modello applicato, se le opzioni sono ancora quelle
  };
  const CAMPI_OPZIONI = ["modo", "valore", "aggiunta", "cerca", "con", "colore", "intervallo"];

  /**
   * Modelli di opzioni riutilizzabili. Solo impostazioni: niente articoli,
   * niente orario di avvio (scade). Massimo 20.
   */
  const MAX_MODELLI = 20;
  const leggiModelli = async () => (await chrome.storage.local.get("queueTemplates")).queueTemplates || [];
  const soloCampi = (o) => Object.fromEntries(CAMPI_OPZIONI.map((k) => [k, String(o?.[k] ?? "")]));
  let opzioni = { ...OPZIONI_VUOTE };

  const L = () => VR.editorLogica;
  const intervalloPredefinito = () => String(VR.settings.queueIntervalMin || 20);
  const conIntervallo = (o) => ({ ...o, intervallo: o.intervallo || intervalloPredefinito() });
  const validate = () => L().validaOpzioniCoda(conIntervallo(opzioni));

  chrome.storage.local.get("queueDraft").then(({ queueDraft }) => {
    if (queueDraft && typeof queueDraft === "object") {
      opzioni = { ...OPZIONI_VUOTE, ...queueDraft, quando: "" };
      disegna();
    }
  });

  const salvaOpzioni = async (nuove) => {
    opzioni = { ...OPZIONI_VUOTE, ...nuove };
    const { quando, ...daSalvare } = opzioni;
    await chrome.storage.local.set({ queueDraft: daSalvare });
    const v = validate();
    if (v.ok) await VR.saveSettings({ queueIntervalMin: v.intervalMin });
  };

  const euro = (n) => Number(n).toLocaleString("it-IT", { style: "currency", currency: "EUR" });

  /** Le opzioni della coda in parole: per il pannello, il riepilogo e la coda in corso. */
  function descriviOverrides(o = {}, { intervalMin = null, startAt = null, modello = null } = {}) {
    o = o || {};
    const parti = [];
    if (modello) parti.push(`modello «${modello}»`);
    if (o.price) parti.push(`prezzo a ${euro(o.price)}`);
    if (o.pricePercent) parti.push(`${o.pricePercent > 0 ? "+" : ""}${o.pricePercent}% sul prezzo`);
    if (o.priceDelta) parti.push(`${o.priceDelta > 0 ? "+" : ""}${euro(o.priceDelta)} sul prezzo`);
    if (o.descriptionAppend) parti.push("riga in fondo alla descrizione");
    if (o.replace?.find) parti.push(o.replace.with ? `«${o.replace.find}» → «${o.replace.with}»` : `tolto «${o.replace.find}»`);
    if (o.autoFill) parti.push("colore dai simili se manca");
    if (o.colorIds?.length) parti.push(`colore ${(VR.settings.colorMap || {})[o.colorIds[0]] || o.colorIds[0]} se manca`);
    if (startAt) parti.push(`parte ${new Date(startAt).toLocaleString("it-IT", { weekday: "short", hour: "2-digit", minute: "2-digit" })}`);
    if (intervalMin) parti.push(`ogni ${intervalMin} min`);
    return parti.length ? parti.join(" · ") : "nessuna modifica";
  }

  function descriviOpzioni() {
    const v = validate();
    if (!v.ok) return "Opzioni da correggere";
    return descriviOverrides(v.overrides || {}, { intervalMin: v.intervalMin, startAt: v.startAt, modello: opzioni.modello });
  }

  /**
   * Menu dei colori costruito sui colori visti nei tuoi articoli.
   * Nessun elenco inventato: si riempie man mano che leggi gli annunci.
   */
  VR.selectColore = (selezionato, { primaVoce = "Nessun colore", conDeduzione = false } = {}) => {
    const noti = Object.entries(VR.settings.colorMap || {}).sort((a, b) => a[1].localeCompare(b[1], "it"));

    const select = VR.h("select", { class: "vr-input" },
      VR.h("option", { value: "" }, noti.length || conDeduzione ? primaVoce : "Nessun colore conosciuto"),
      conDeduzione ? VR.h("option", { value: "auto" }, "Deduci dai tuoi articoli simili") : null
    );
    for (const [id, nome] of noti) select.append(VR.h("option", { value: id }, nome));
    if (selezionato) select.value = String(selezionato);
    select.disabled = !noti.length && !conDeduzione;
    return select;
  };

  /** Titolo e miniatura di un articolo, dalla card che hai davanti. */
  function infoCard(id) {
    const link = document.querySelector(`a[href*="/items/${id}"]`);
    const testo = (link?.getAttribute("title") || link?.textContent || "").trim();
    const card = link?.closest('[class*="new-item-box__container"], .feed-grid__item') || link?.parentElement;
    const img = card?.querySelector("img");
    return { id, title: testo ? testo.slice(0, 80) : `Articolo ${id}`, thumb: img?.currentSrc || img?.src || null };
  }

  // ------------------------------------------------------- finestra opzioni

  /** Il nome che avra' la prossima batch della coda in corso. */
  function nomeProssimaBatch() {
    const c = CL().migra(coda);
    return `Batch ${Math.max(c?.batchSeq || 0, c?.batches?.length || 0) + 1}`;
  }

  /**
   * perBatch: Centro di modifica per gli articoli da AGGIUNGERE alla coda in
   * corso. Stesse regole di sempre (prezzo, testo, dati mancanti), niente
   * pianificazione (intervallo e avvio sono della sessione). Risolve con
   * { overrides, campi, modello } oppure null se chiudi.
   */
  async function apriOpzioni({ eAvvia = false, perBatch = false } = {}) {
    // Il toast in basso copriva i controlli: si chiude, l'evento resta nel registro.
    VR.toast.chiudiTutti();
    const h2 = VR.h;
    let risolviBatch = null;
    const promessa = perBatch ? new Promise((r) => { risolviBatch = r; }) : null;
    const sessione = perBatch ? CL().migra(coda) : null;
    const formaDi = (o) => ({ ...soloCampi(conIntervallo(o)), quando: String(o.quando || "") });
    let f = formaDi(opzioni);
    const salvate = JSON.stringify(formaDi(opzioni));
    let modelli = await leggiModelli();
    let modelloApplicato = opzioni.modello || "";

    const campo = (etichetta, input, nome, nota) => {
      const errore = h2("p", { class: "vr-field__error", id: `vr-err-${nome}`, hidden: true });
      input.setAttribute("aria-describedby", `vr-err-${nome}`);
      return { nodo: h2("label", { class: "vr-field" },
        h2("span", { class: "vr-field__label" }, etichetta), input,
        nota ? h2("span", { class: "vr-field__help" }, nota) : null, errore), errore };
    };

    const modo = h2("select", { class: "vr-input" },
      h2("option", { value: "" }, "Prezzo invariato"),
      h2("option", { value: "percent" }, "Variazione in percentuale"),
      h2("option", { value: "delta" }, "Variazione in euro"),
      h2("option", { value: "fixed" }, "Prezzo fisso per tutti"));
    const valore = h2("input", { class: "vr-input", type: "text", inputmode: "decimal" });
    const unita = h2("span", { class: "vr-unit" });
    const anteprima = h2("p", { class: "vr-preview-price", "aria-live": "polite" });
    const aggiunta = h2("textarea", { class: "vr-input vr-input--area", rows: "3", placeholder: "Es. Spedizione rapida entro 24 ore." });
    const cerca = h2("input", { class: "vr-input", type: "text", placeholder: "es. #starwars" });
    const con = h2("input", { class: "vr-input", type: "text", placeholder: "vuoto = togli" });
    const colore = VR.selectColore(f.colore, { primaVoce: "Lascia come è", conDeduzione: true });
    const quando = h2("input", { class: "vr-input", type: "datetime-local" });
    const intervallo = h2("input", { class: "vr-input", type: "number", min: "1", max: "240", step: "1" });

    modo.value = f.modo; valore.value = f.valore; aggiunta.value = f.aggiunta; cerca.value = f.cerca;
    con.value = f.con; colore.value = f.colore || ""; quando.value = f.quando; intervallo.value = f.intervallo;
    // L'intervallo e' della sessione: per una batch non si sceglie, ma serve valido per la validazione.
    // 2.4.0: ogni batch ha il suo intervallo. Si parte da quello dell'ultima batch, modificabile.
    const ultimaBatch = perBatch ? (sessione?.batches || []).slice(-1)[0] : null;
    if (perBatch) { quando.value = ""; intervallo.value = String(ultimaBatch?.intervalMin || sessione?.intervalMin || 20); }

    const cValore = campo("Valore", h2("span", { class: "vr-input-unit" }, valore, unita), "valore");
    const cAggiunta = campo("Aggiungi in fondo alla descrizione", aggiunta, "aggiunta");
    const cCerca = campo("Cerca nel titolo e nella descrizione", cerca, "cerca");
    const cCon = campo("Sostituisci con", con, "con");
    const cColore = campo("Colore, dove manca", colore, "colore",
      VR.settings.autoFill !== false ? "Il riempimento dai simili è già attivo nelle impostazioni." : null);
    const cQuando = campo("Avvia alle", quando, "quando", "Vuoto = subito.");
    const cIntervallo = campo("Intervallo tra gli articoli (minuti)", intervallo, "intervallo",
      VR.settings.peakOnly ? "Le fasce di picco sono attive: fuori fascia la coda aspetta." : null);
    const errori = { valore: cValore.errore, aggiunta: cAggiunta.errore, cerca: cCerca.errore, quando: cQuando.errore, intervallo: cIntervallo.errore };

    const statoBozza = h2("span", { class: "vr-editor__badge" });

    // ----- modelli
    const etichettaModello = h2("span", { class: "vr-field__help" });
    const sceltaModello = h2("select", { class: "vr-input vr-input--sm", "aria-label": "Modello di opzioni" });
    const zonaModelli = h2("div", { class: "vr-templates__ask", hidden: true, role: "group" });
    const bApplica = h2("button", { class: "vr-btn vr-btn--ghost vr-btn--sm", type: "button" }, "Applica");
    const bElimina = h2("button", { class: "vr-btn vr-btn--quiet vr-btn--sm", type: "button" }, "Elimina");
    const bSalvaModello = h2("button", { class: "vr-btn vr-btn--ghost vr-btn--sm", type: "button" }, "Salva come modello…");

    function riempiModelli(selezionato = "") {
      sceltaModello.textContent = "";
      sceltaModello.append(h2("option", { value: "" }, modelli.length ? "Scegli un modello…" : "Nessun modello salvato"));
      for (const m of modelli) sceltaModello.append(h2("option", { value: m.nome }, m.nome));
      sceltaModello.value = selezionato;
      sceltaModello.disabled = !modelli.length;
      bApplica.disabled = !sceltaModello.value;
      bElimina.disabled = !sceltaModello.value;
    }
    sceltaModello.addEventListener("change", () => { bApplica.disabled = bElimina.disabled = !sceltaModello.value; chiediChiudi(); });

    /** Domanda in linea al posto di un confirm(): testo, pulsanti, e si richiude. */
    function chiedi(testo, azioni) {
      zonaModelli.textContent = "";
      zonaModelli.hidden = false;
      zonaModelli.append(h2("span", {}, testo), ...azioni.map(([etichetta, fn, classe]) =>
        h2("button", { class: `vr-btn vr-btn--${classe || "ghost"} vr-btn--sm`, type: "button", onclick: fn }, etichetta)));
      zonaModelli.querySelector("input, button")?.focus();
    }
    function chiediChiudi() { zonaModelli.hidden = true; zonaModelli.textContent = ""; }

    function applicaModello(m) {
      const o = soloCampi(m.opzioni);
      modo.value = o.modo; valore.value = o.valore; aggiunta.value = o.aggiunta; cerca.value = o.cerca;
      con.value = o.con; colore.value = o.colore || ""; intervallo.value = o.intervallo || intervalloPredefinito();
      modelloApplicato = m.nome;
      chiediChiudi();
      aggiorna();
    }

    bApplica.addEventListener("click", () => {
      const m = modelli.find((x) => x.nome === sceltaModello.value);
      if (!m) return;
      const sporco = JSON.stringify(f) !== salvate;
      if (!sporco) return applicaModello(m);
      chiedi(`Hai modifiche non salvate: sostituirle con «${m.nome}»?`, [
        ["Sostituisci", () => applicaModello(m), "primary"], ["Annulla", chiediChiudi]]);
    });

    bElimina.addEventListener("click", () => {
      const nome = sceltaModello.value;
      if (!nome) return;
      chiedi(`Eliminare il modello «${nome}»? Le code già avviate non cambiano.`, [
        ["Elimina", async () => {
          modelli = modelli.filter((x) => x.nome !== nome);
          await chrome.storage.local.set({ queueTemplates: modelli });
          if (modelloApplicato === nome) modelloApplicato = "";
          riempiModelli();
          chiediChiudi();
          aggiorna();
        }, "primary"], ["Annulla", chiediChiudi]]);
    });

    bSalvaModello.addEventListener("click", () => {
      if (!aggiorna().ok) {
        chiedi("Correggi prima i campi segnati: un modello si salva solo se valido.", [["Ok", chiediChiudi]]);
        return;
      }
      const nome = h2("input", { class: "vr-input vr-input--sm", type: "text", maxlength: "40", placeholder: "Nome del modello", "aria-label": "Nome del modello" });
      nome.value = modelloApplicato || "";
      const salva = async (sostituisci = false) => {
        const n = nome.value.trim().replace(/\s+/g, " ").slice(0, 40);
        if (!n) { nome.focus(); return; }
        if (!sostituisci && modelli.some((x) => x.nome === n)) {
          chiedi(`Esiste già un modello «${n}»: sostituirlo?`, [["Sostituisci", () => { nome.value = n; salvaVero(n); }, "primary"], ["Annulla", chiediChiudi]]);
          return;
        }
        salvaVero(n);
      };
      const salvaVero = async (n) => {
        if (!modelli.some((x) => x.nome === n) && modelli.length >= MAX_MODELLI) {
          chiedi(`Al massimo ${MAX_MODELLI} modelli: eliminane uno prima.`, [["Ok", chiediChiudi]]);
          return;
        }
        const voce = { nome: n, opzioni: soloCampi(f), creato: Date.now() };
        modelli = [voce, ...modelli.filter((x) => x.nome !== n)];
        await chrome.storage.local.set({ queueTemplates: modelli });
        modelloApplicato = n;
        riempiModelli(n);
        chiediChiudi();
        aggiorna();
      };
      nome.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); salva(); } });
      chiedi("Salva le opzioni attuali come:", [["Salva", () => salva(), "primary"], ["Annulla", chiediChiudi]]);
      zonaModelli.insertBefore(nome, zonaModelli.children[1]);
      nome.focus();
    });
    riempiModelli();
    const bSalva = h2("button", { class: "vr-btn vr-btn--ghost", type: "button" }, "Salva");
    const bAvvia = h2("button", { class: "vr-btn vr-btn--primary", type: "button" }, "Salva e avvia");
    const bContinua = h2("button", { class: "vr-btn vr-btn--primary", type: "button" }, "Continua al riepilogo");

    // Partire dalle regole di una batch gia' in coda (copiate: quella non cambia).
    const copiaDa = perBatch
      ? (sessione?.batches || []).filter((b) => b.campi).map((b) =>
        h2("button", {
          class: "vr-btn vr-btn--ghost vr-btn--sm", type: "button", title: descriviOverrides(b.overrides || {}),
          onclick: () => {
            const o = b.campi;
            modo.value = o.modo || ""; valore.value = o.valore || ""; aggiunta.value = o.aggiunta || "";
            cerca.value = o.cerca || ""; con.value = o.con || ""; colore.value = o.colore || "";
            if (b.intervalMin) intervallo.value = String(b.intervalMin);
            modelloApplicato = b.modello || "";
            aggiorna();
          },
        }, `Copia da ${b.nome}`))
      : [];

    // prezzo di esempio: il primo articolo selezionato di cui conosciamo il prezzo
    const { inventory = {} } = await chrome.storage.local.get("inventory");
    const esempio = [...selezionati].map((id) => ({ id, ...inventory[id] })).find((a) => typeof a.price === "number");

    function aggiorna() {
      f = { modo: modo.value, valore: valore.value, aggiunta: aggiunta.value, cerca: cerca.value,
            con: con.value, colore: colore.value, intervallo: intervallo.value, quando: quando.value };
      const v = L().validaOpzioniCoda(f);

      // Il nome del modello resta solo finche' le opzioni sono le sue.
      const m = modelli.find((x) => x.nome === modelloApplicato);
      if (modelloApplicato && (!m || JSON.stringify(soloCampi(m.opzioni)) !== JSON.stringify(soloCampi(f)))) modelloApplicato = "";
      etichettaModello.textContent = modelloApplicato ? `Modello «${modelloApplicato}»` : "";

      cValore.nodo.hidden = !f.modo;
      unita.textContent = f.modo === "percent" ? "%" : f.modo ? "€" : "";
      valore.placeholder = { percent: "es. -10", delta: "es. -0,50", fixed: "es. 8,50" }[f.modo] || "";
      cCon.nodo.hidden = !f.cerca;

      for (const [nome, nodo] of Object.entries(errori)) {
        nodo.hidden = !v.errori[nome];
        nodo.textContent = v.errori[nome] || "";
        nodo.previousElementSibling?.classList?.toggle("is-invalid", Boolean(v.errori[nome]));
      }

      if (!f.modo) anteprima.textContent = "";
      else if (v.errori.valore) anteprima.textContent = "";
      else if (!esempio) anteprima.textContent = "Anteprima non disponibile: il prezzo degli articoli selezionati non è ancora stato letto.";
      else {
        // solo i campi del prezzo: un errore altrove (es. l'intervallo) non deve falsare l'anteprima
        const soloPrezzo = L().validaOpzioniCoda({ modo: f.modo, valore: f.valore, intervallo: "20" });
        const dopo = L().applicaPrezzo(esempio.price, soloPrezzo.overrides || {});
        anteprima.textContent = `Su «${(esempio.title || "").slice(0, 40)}»: ${euro(esempio.price)} → ${euro(dopo)}`;
      }

      const modificato = JSON.stringify(f) !== salvate;
      statoBozza.textContent = modificato ? "Modifiche non salvate" : "Salvate";
      statoBozza.classList.toggle("is-dirty", modificato);
      bSalva.disabled = !v.ok;
      bAvvia.disabled = !v.ok;
      bContinua.disabled = !v.ok;
      return v;
    }

    for (const el of [modo, valore, aggiunta, cerca, con, colore, quando, intervallo]) {
      el.addEventListener("input", aggiorna);
      el.addEventListener("change", aggiorna);
    }

    const sezione = (titolo, ...figli) =>
      h2("fieldset", { class: "vr-section" }, h2("legend", { class: "vr-section__title" }, titolo), ...figli);

    const card = h2("div", { class: "vr-card vr-card--wide vr-options", role: "dialog", "aria-modal": "true", "aria-labelledby": "vr-opt-title" },
      h2("div", { class: "vr-editor__head" },
        h2("h2", { class: "vr-card__title", id: "vr-opt-title" }, perBatch ? `Centro di modifica · ${nomeProssimaBatch()}` : "Opzioni della coda"),
        perBatch ? null : statoBozza,
        h2("button", { class: "vr-close", type: "button", "aria-label": "Chiudi senza salvare", title: "Chiudi senza salvare", onclick: () => chiudi() }, "×")),
      h2("p", { class: "vr-note" }, perBatch
        ? `Regole per i ${selezionati.size} ${selezionati.size === 1 ? "articolo" : "articoli"} da aggiungere alla coda in corso, che diventano «${nomeProssimaBatch()}». La coda non si ferma e le batch già in coda tengono le loro regole.`
        : `Valgono per ${selezionati.size} ${selezionati.size === 1 ? "articolo selezionato" : "articoli selezionati"}. Foto, titolo intero e taglia si cambiano dal singolo articolo con Modifica.`),
      coda?.running && !perBatch
        ? h2("p", { class: "vr-note vr-note--warn" }, "C'è una coda in corso: queste opzioni valgono per la prossima coda. Per aggiungere articoli a quella in corso usa «Aggiungi alla coda»: potrai scegliere regole diverse per loro.")
        : null,
      copiaDa.length ? h2("div", { class: "vr-templates" }, h2("span", { class: "vr-field__label" }, "Parti da"), ...copiaDa) : null,
      h2("div", { class: "vr-templates" },
        h2("label", { class: "vr-templates__pick" }, h2("span", { class: "vr-field__label" }, "Modello"), sceltaModello),
        bApplica, bElimina, h2("span", { class: "vr-templates__spacer" }), bSalvaModello),
      zonaModelli,
      etichettaModello,
      sezione("Prezzo",
        h2("div", { class: "vr-row" }, campo("Modalità", modo, "modo").nodo, cValore.nodo),
        anteprima),
      sezione("Testo e descrizione",
        cAggiunta.nodo,
        h2("div", { class: "vr-row" }, cCerca.nodo, cCon.nodo),
        h2("p", { class: "vr-field__help" }, "La ricerca è letterale e ignora le maiuscole: niente caratteri speciali da conoscere.")),
      sezione("Dati mancanti",
        cColore.nodo,
        h2("p", { class: "vr-field__help" },
          "Gli articoli che hanno già un colore restano com'erano. " +
          (VR.settings.canary !== false
            ? "Prima di avviare, ogni articolo viene letto (senza pubblicare) e ti dico cosa manca."
            : "Il controllo prima di avviare è spento nelle impostazioni."))),
      perBatch
        ? sezione("Tempo tra le ripubblicazioni",
          h2("div", { class: "vr-row" }, cIntervallo.nodo),
          h2("p", { class: "vr-field__help" }, "Vale per gli articoli di questa batch: è l'attesa prima di ognuno di loro. Le altre batch tengono il loro; l'attesa già in corso non cambia."))
        : sezione("Pianificazione", h2("div", { class: "vr-row" }, cQuando.nodo, cIntervallo.nodo)),
      h2("div", { class: "vr-actions vr-actions--split" },
        h2("button", {
          class: "vr-btn vr-btn--quiet", type: "button",
          onclick: () => {
            modo.value = ""; valore.value = ""; aggiunta.value = ""; cerca.value = ""; con.value = "";
            colore.value = ""; quando.value = ""; intervallo.value = perBatch ? String(ultimaBatch?.intervalMin || sessione?.intervalMin || 20) : "20";
            modelloApplicato = "";
            aggiorna();
          },
        }, perBatch ? "Nessuna modifica" : "Ripristina predefiniti"),
        h2("span", { class: "vr-actions__group" },
          h2("button", { class: "vr-btn vr-btn--ghost", type: "button", onclick: () => chiudi() }, "Annulla"),
          ...(perBatch ? [bContinua] : [bSalva, bAvvia])))
    );

    bContinua.addEventListener("click", async () => {
      const v = aggiorna();
      if (!v.ok) return;
      // Le regole scelte diventano anche le ultime usate; intervallo e avvio salvati restano i tuoi.
      await salvaOpzioni({ ...opzioni, ...soloCampi(f), intervallo: opzioni.intervallo, quando: "", modello: modelloApplicato });
      risolviBatch({ overrides: v.overrides || null, campi: Object.fromEntries(["modo", "valore", "aggiunta", "cerca", "con", "colore"].map((k) => [k, f[k] || ""])), modello: modelloApplicato || null, intervalMin: v.intervalMin });
      chiudi();
    });

    bSalva.addEventListener("click", async () => {
      if (!aggiorna().ok) return;
      await salvaOpzioni({ ...f, modello: modelloApplicato });
      chiudi();
      disegna();
    });
    bAvvia.addEventListener("click", async () => {
      if (!aggiorna().ok) return;
      await salvaOpzioni({ ...f, modello: modelloApplicato });
      chiudi();
      disegna();
      parti();
    });

    aggiorna();
    const chiudi = VR.openOverlay(card, perBatch ? { onClose: () => risolviBatch(null) } : undefined);
    (perBatch ? modo : eAvvia ? bAvvia : modo).focus();
    return promessa;
  }

  // ------------------------------------------------------ controllo preventivo

  const CL = () => window.CodaLogica;

  /**
   * Legge ogni articolo selezionato, senza pubblicare niente, e li divide in
   * pronti, con avvisi e bloccati. La foto si prova a scaricare solo sul primo:
   * per gli altri basta sapere che ce l'hanno.
   * Non garantisce il risultato: Vinted decide al momento della pubblicazione.
   */
  async function controlloPreventivo(items, overrides, avanzamento) {
    const { vrQueue: precedente, vrQueueArchive = [] } = await chrome.storage.local.get(["vrQueue", "vrQueueArchive"]);
    // Incerti delle ultime sessioni: potrebbero essere gia' stati ripubblicati.
    const daVerificare = new Set();
    for (const s of [precedente, ...vrQueueArchive.slice(0, 3)]) {
      for (const i of s?.items || []) if (i.status === "verify") daVerificare.add(String(i.id));
    }

    const esiti = [];
    for (let i = 0; i < items.length; i++) {
      avanzamento(i + 1, items.length);
      const it = items[i];
      const r = await VR.canary(it.id, overrides || {}, { foto: i === 0 });
      const avvisi = [...(r.avvisi || [])];
      if (daVerificare.has(String(it.id))) {
        avvisi.unshift("era «da verificare» in una sessione recente: controlla che non sia già stato ripubblicato");
      }
      esiti.push({ ...it, ok: r.ok, problemi: r.problemi || [], avvisi, note: r.note || [], sessione: r.sessione });
      if (r.sessione) break;            // senza sessione e' inutile leggere gli altri
      if (i < items.length - 1) await VR.sleep(400);
    }
    return esiti;
  }

  /**
   * Riepilogo prima di avviare (o di aggiungere a una coda in corso): cosa
   * parte, in che ordine, con quali opzioni, quali prezzi cambiano e cosa resta
   * fuori e perche'. Risolve con { items, dove } oppure null.
   */
  function mostraRiepilogo({ voci, controllati, rifiutati = [], attiva, overrides = {}, descrizione, totale }) {
    const h2 = VR.h;
    const bloccati = voci.filter((e) => e.ok === false);
    const utilizzabili = voci.filter((e) => e.ok !== false);
    const conAvvisi = utilizzabili.filter((e) => (e.avvisi || []).length);
    const pronti = utilizzabili.filter((e) => !(e.avvisi || []).length);
    const conNote = voci.filter((e) => (e.note || []).length);
    const sessione = voci.find((e) => e.sessione);
    const nonControllati = controllati ? Math.max(0, totale - voci.length) : 0;

    return new Promise((risolvi) => {
      const elenco = (lista, testo) => h2("ul", { class: "vr-check-list" },
        lista.map((e) => h2("li", {}, h2("strong", {}, e.title), " — ", testo(e))));

      const prezzo = (e) => {
        if (typeof e.price !== "number") return null;
        const dopo = L().applicaPrezzo(e.price, overrides || {});
        return dopo !== e.price
          ? h2("span", { class: "vr-plan__price" }, `${euro(e.price)} → `, h2("b", {}, euro(dopo)))
          : h2("span", { class: "vr-plan__price" }, euro(e.price));
      };

      const piano = h2("ol", { class: "vr-plan", "aria-label": attiva ? "Articoli da aggiungere" : "Ordine di pubblicazione" },
        utilizzabili.map((e) => h2("li", {},
          h2("span", { class: "vr-plan__title" }, e.title),
          prezzo(e),
          (e.avvisi || []).length ? h2("span", { class: "vr-tag vr-tag--warn" }, `⚠ ${e.avvisi.length}`) : null)));

      let dove = "fondo";
      const scegliDove = attiva
        ? h2("fieldset", { class: "vr-section vr-dove" },
          h2("legend", { class: "vr-section__title" }, "Dove inserirli"),
          ...[["fondo", "In fondo alla coda"], ["cima", "In cima, subito dopo quello in corso"]].map(([valore, testo]) => {
            const radio = h2("input", { type: "radio", name: "vr-dove", value: valore, checked: valore === "fondo" ? "" : null });
            radio.addEventListener("change", () => { if (radio.checked) dove = valore; });
            return h2("label", { class: "vr-radio" }, radio, " ", testo);
          }))
        : null;

      const n = utilizzabili.length;
      const conferma = h2("button", { class: "vr-btn vr-btn--primary", type: "button" },
        attiva ? `Aggiungi ${n}` : bloccati.length ? `Avvia solo i ${n} utilizzabili` : `Avvia ${n}`);
      conferma.disabled = !n;

      const card = h2("div", { class: "vr-card vr-card--wide", role: "dialog", "aria-modal": "true", "aria-labelledby": "vr-riep-title" },
        h2("h2", { class: "vr-card__title", id: "vr-riep-title" }, attiva ? "Aggiungi alla coda in corso" : "Prima di avviare"),
        h2("p", { class: "vr-note" }, attiva ? `Nuova ${descrizione}. La coda non si ferma e le batch già in coda non cambiano.` : `Opzioni: ${descrizione}.`),
        sessione
          ? h2("p", { class: "vr-note vr-note--error" }, `Non riesco a leggere gli articoli: ${sessione.problemi[0]}. Ricarica Vinted e controlla di essere entrato.`)
          : null,
        h2("div", { class: "vr-summary" },
          h2("span", { class: "is-ok" }, h2("b", {}, pronti.length), " pronti"),
          h2("span", { class: "is-warn" }, h2("b", {}, conAvvisi.length), " con avvisi"),
          h2("span", { class: "is-error" }, h2("b", {}, bloccati.length), " bloccati"),
          rifiutati.length ? h2("span", {}, h2("b", {}, rifiutati.length), attiva ? " non aggiungibili" : " esclusi") : null,
          nonControllati ? h2("span", {}, h2("b", {}, nonControllati), " non controllati") : null),
        controllati ? null : h2("p", { class: "vr-field__help" }, "Controllo prima di avviare spento nelle impostazioni: gli articoli non sono stati letti."),
        n ? h2("details", { open: n <= 12 ? "" : null }, h2("summary", {}, attiva ? `Da aggiungere (${n})` : `Ordine di pubblicazione (${n})`), piano) : null,
        scegliDove,
        bloccati.length ? h2("div", {}, h2("p", { class: "vr-section__title" }, "Bloccati: Vinted li rifiuterebbe"), elenco(bloccati, (e) => e.problemi.join("; "))) : null,
        rifiutati.length ? h2("details", { open: "" }, h2("summary", {}, `${attiva ? "Non aggiungibili" : "Esclusi"} (${rifiutati.length})`), elenco(rifiutati, (e) => e.motivo)) : null,
        conAvvisi.length ? h2("details", {}, h2("summary", {}, `Avvisi (${conAvvisi.length})`), elenco(conAvvisi, (e) => e.avvisi.join("; "))) : null,
        // Assenze legittime (es. un libro senza colore): visibili, ma non contano come avvisi.
        conNote.length ? h2("details", {}, h2("summary", {}, `Note, non sono problemi (${conNote.length})`), elenco(conNote, (e) => e.note.join("; "))) : null,
        h2("p", { class: "vr-field__help" }, "Il controllo non garantisce il risultato: la decisione finale è di Vinted, al momento della pubblicazione."),
        h2("div", { class: "vr-actions" },
          h2("button", { class: "vr-btn vr-btn--ghost", type: "button", onclick: () => { risolvi(null); chiudi(); } }, "Annulla"),
          conferma));

      // prima la risposta, poi la chiusura: chiudere risponde "annullato"
      conferma.addEventListener("click", () => { risolvi({ items: utilizzabili, dove }); chiudi(); });
      const chiudi = VR.openOverlay(card, { onClose: () => risolvi(null) });
      conferma.focus();
    });
  }

  // ------------------------------------------------------------------- avvio

  /**
   * Avvia una coda nuova, oppure — se una coda e' gia' in corso — aggiunge gli
   * articoli selezionati a quella, senza fermarla. In entrambi i casi passa dal
   * riepilogo: niente parte senza che tu l'abbia visto.
   */
  async function parti() {
    if (controlloInCorso) return;          // doppio clic
    // Si ricontrolla al momento: la pagina potrebbe essere cambiata dopo il disegno.
    if (!VR.nelMioArmadio?.()) {
      VR.toast("La coda si avvia solo dal tuo armadio, con il tuo account riconosciuto.", "warn", { chiave: "avvio-coda" });
      return;
    }
    const attiva = Boolean(coda?.running);
    if (attiva && coda.stopDopoCorrente) {
      VR.toast("La coda si sta chiudendo: aspetta che finisca, poi avviane una nuova.", "warn", { chiave: "avvio-coda" });
      return;
    }
    const v = validate();
    if (!attiva && !v.ok) return apriOpzioni({ eAvvia: true });

    const { inventory = {} } = await chrome.storage.local.get("inventory");
    const tutti = [...selezionati].map((id) => ({
      ...infoCard(id),
      price: typeof inventory[id]?.price === "number" ? inventory[id].price : null,
    }));
    if (!tutti.length) return;

    // Coda in corso: i nuovi articoli sono una batch nuova, con regole scelte
    // adesso nel Centro di modifica. Quella che lavora non si ferma.
    let regole = null;
    let nomeBatch = null;
    if (attiva) {
      nomeBatch = nomeProssimaBatch();
      regole = await apriOpzioni({ perBatch: true });
      if (!regole) return;
    }
    const overrides = attiva ? regole.overrides || {} : v.overrides || {};

    // Con una coda in corso: chi non puo' entrare (gia' in coda, completato,
    // da verificare) lo dice la stessa regola che usa il service worker.
    const rifiutati = attiva
      ? CL().valutaAggiunta(coda, tutti).filter((x) => x.esito === "rifiuta")
        .map((x) => ({ ...tutti.find((t) => t.id === x.id), motivo: x.motivo }))
      : [];
    const daControllare = tutti.filter((t) => !rifiutati.some((r) => r.id === t.id));

    let voci = daControllare;
    let controllati = false;
    if (daControllare.length && VR.settings.canary !== false) {
      controlloInCorso = true;
      disegna();
      try {
        voci = await controlloPreventivo(daControllare, overrides, (n, tot) => {
          const t = pannello?.querySelector(".vr-queue__title");
          if (t) t.textContent = `Controllo ${n} di ${tot}…`;
        });
        controllati = true;
      } finally {
        controlloInCorso = false;
        disegna();
      }
    }

    const scelta = await mostraRiepilogo({
      voci, controllati, rifiutati, attiva, overrides, totale: daControllare.length,
      descrizione: attiva ? `${nomeBatch}: ${descriviOverrides(regole.overrides || {}, { modello: regole.modello, intervalMin: regole.intervalMin })}` : descriviOpzioni(),
    });
    if (!scelta) return;
    const items = scelta.items.map(({ id, title, thumb, price }) => ({ id, title, thumb, price }));

    if (attiva) {
      const r = await chrome.runtime.sendMessage({ type: "vr:queueAdd", items, dove: scelta.dove, batch: regole });
      if (r?.ok) {
        const n = (r.aggiunti?.length || 0) + (r.riattivati?.length || 0);
        const fuori = r.rifiutati?.length || 0;
        VR.toast(`${n} ${n === 1 ? "articolo aggiunto" : "articoli aggiunti"} alla coda come ${nomeBatch}${fuori ? `; ${fuori} non aggiunti (${r.rifiutati[0].motivo})` : ""}.`,
          fuori ? "warn" : "ok", { chiave: "aggiunta-coda" });
        VR.selection.nessuno();
      } else {
        VR.toast(r?.error || r?.rifiutati?.[0]?.motivo || "Non sono riuscito ad aggiungere gli articoli.", "error", { chiave: "aggiunta-coda" });
      }
      return;
    }

    const esito = await chrome.runtime.sendMessage({
      type: "vr:queueStart",
      items,
      intervalMin: v.intervalMin,
      overrides: v.overrides,
      campi: Object.fromEntries(["modo", "valore", "aggiunta", "cerca", "con", "colore"].map((k) => [k, String(opzioni[k] || "")])),
      startAt: v.startAt,
      modello: opzioni.modello || null,
    });

    if (esito?.ok) {
      // l'orario di avvio vale una volta sola
      if (opzioni.quando) await salvaOpzioni({ ...opzioni, quando: "" });
      VR.selection.nessuno();
    } else {
      VR.toast(esito?.error || "Non sono riuscito ad avviare la coda.", "error", { chiave: "avvio-coda" });
    }
  }

  // ------------------------------------------------------------------ disegno

  function creaPannello() {
    pannello = h("div", { class: "vr-queue", role: "region", "aria-label": "Coda di ripubblicazione" },
      h("div", { class: "vr-queue__info" },
        h("span", { class: "vr-queue__title" }),
        h("span", { class: "vr-queue__sub" })),
      h("div", { class: "vr-queue__controls" }));
    document.body.append(pannello);
  }

  function manca(ms) {
    if (ms <= 0) return "a momenti";
    const min = Math.floor(ms / 60000);
    const sec = Math.floor((ms % 60000) / 1000);
    return min > 0 ? `tra ${min} min ${String(sec).padStart(2, "0")}s` : `tra ${sec}s`;
  }

  const bottone = (testo, classe, azione, attributi = {}) =>
    h("button", { class: `vr-btn vr-btn--${classe} vr-btn--sm`, type: "button", onclick: azione, ...attributi }, testo);

  /** Comando al service worker: se rifiuta, il motivo si vede. */
  const comando = (tipo, extra = {}) => async () => {
    const r = await chrome.runtime.sendMessage({ type: tipo, ...extra }).catch((e) => ({ ok: false, error: e.message }));
    if (r && r.ok === false && (r.motivo || r.error)) VR.toast(r.motivo || r.error, "warn", { chiave: `cmd:${tipo}` });
    return r;
  };

  /** Il passo dell'articolo che QUESTA scheda sta lavorando (le altre non lo vedono). */
  let passoLocale = null;

  function disegna() {
    // 2.3: pannello, selezione e comandi della coda solo nel tuo armadio. La
    // coda lavora anche se la scheda e' altrove; il suo stato e' nel popup e
    // nella dashboard.
    if (!VR.nelMioArmadio?.()) {
      pannello?.remove();
      pannello = null;
      clearInterval(tic);
      tic = null;
      return;
    }
    const inCorso = Boolean(coda?.running);
    const conclusa = Boolean(coda && !coda.running && coda.finishedAt);
    const quanti = selezionati.size;

    if (!inCorso && !conclusa && !quanti && !controlloInCorso) {
      pannello?.remove();
      pannello = null;
      clearInterval(tic);
      tic = null;
      return;
    }

    if (!pannello) creaPannello();
    else if (!pannello.isConnected) document.body.append(pannello);

    const titolo = pannello.querySelector(".vr-queue__title");
    const sotto = pannello.querySelector(".vr-queue__sub");
    const controlli = pannello.querySelector(".vr-queue__controls");
    controlli.textContent = "";
    pannello.dataset.stato = inCorso ? coda.state : conclusa ? "done" : "select";

    if (controlloInCorso) {
      titolo.textContent = "Controllo prima di avviare…";
      sotto.textContent = "Leggo gli articoli selezionati: niente viene pubblicato.";
      return;
    }

    const gestisci = () => bottone("Gestisci", "ghost", comando("vr:openPage", { pagina: "src/dashboard.html#coda" }), { title: "Apri la gestione della coda" });
    // Con una coda in corso, la selezione si aggiunge a quella: non serve fermarla.
    const aggiunta = () => (quanti && !coda.stopDopoCorrente
      ? [bottone(`Aggiungi alla coda (${quanti})`, "primary", (e) => { e.currentTarget.disabled = true; parti().finally(disegna); }),
        bottone("Nessuno", "ghost", () => VR.selection.nessuno())]
      : []);

    if (inCorso) {
      const C = CL();
      const r = C.conta(coda);
      const cor = C.corrente(coda);
      const pros = C.prossimo(coda);

      if (coda.state === "recovering") {
        titolo.textContent = "Coda interrotta";
        sotto.textContent = `${r.done} completati` + (r.verify ? `, ${r.verify} da verificare` : "") +
          (r.skipped ? `, ${r.skipped} saltati` : "") + `, ${r.pending} in attesa`;
        controlli.append(gestisci(), bottone("Interrompi", "ghost", comando("vr:queueStop")), bottone("Riprendi", "primary", comando("vr:queueRecover")));
      } else if (coda.stopDopoCorrente) {
        titolo.textContent = "Coda in chiusura";
        sotto.textContent = cor ? `Aspetto l'esito di: ${cor.title}` : "";
        controlli.append(gestisci());
      } else if (coda.state === "paused") {
        titolo.textContent = `Coda in pausa: ${r.trattati} di ${r.totale}${coda.pausaAuto ? " — fermata da sola" : ""}`;
        sotto.textContent = coda.motivoPausa ||
          (coda.riprendiAlle ? `Riprende alle ${new Date(coda.riprendiAlle).toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" })}` : "Riprende da dove si era fermata.");
        controlli.append(...aggiunta(), gestisci(), bottone("Interrompi", "ghost", comando("vr:queueStop")), bottone("Riprendi", "primary", comando("vr:queueResume")));
      } else if (coda.state === "scheduled") {
        titolo.textContent = `Coda programmata: ${r.totale} articoli`;
        sotto.textContent = `Parte ${new Date(coda.nextAt).toLocaleString("it-IT", { weekday: "long", hour: "2-digit", minute: "2-digit" })}`;
        controlli.append(...aggiunta(), gestisci(), bottone("Annulla", "ghost", comando("vr:queueStop")));
      } else {
        titolo.textContent = `Coda: ${r.trattati} di ${r.totale}`;
        // Il conto alla rovescia sta nel titolo: nel sottotitolo i nomi lunghi lo tagliavano.
        if (cor) titolo.textContent += " — in corso";
        else if (coda.nextAt) titolo.textContent += ` — ${manca(coda.nextAt - Date.now())}`;
        const passo = cor && passoLocale?.id === cor.id ? ` · ${passoLocale.testo}` : "";
        sotto.textContent = coda.note || (cor ? `${cor.title}${passo}` : pros ? `Prossimo: ${pros.title}` : "");
        controlli.append(...aggiunta(), gestisci(),
          bottone(coda.pausaDopoCorrente ? "Pausa richiesta" : "Pausa", "ghost", comando("vr:queuePause"), { disabled: coda.pausaDopoCorrente ? "" : null }),
          bottone("Interrompi", "ghost", comando("vr:queueStop")));
        if (!tic) tic = setInterval(disegna, 1000);
        return;
      }
      clearInterval(tic);
      tic = null;
      return;
    }

    clearInterval(tic);
    tic = null;

    if (conclusa && !quanti) {
      const r = CL().conta(coda);
      const daGuardare = r.error + r.verify + r.interrupted;
      titolo.textContent = daGuardare
        ? `Finita: ${r.done} ripubblicati, ${daGuardare} da guardare`
        : `Finita: ${r.done} ripubblicati`;
      sotto.textContent = coda.note || [
        r.error ? `${r.error} falliti` : "",
        r.verify ? `${r.verify} da verificare` : "",
        r.interrupted ? `${r.interrupted} interrotti` : "",
        r.cancelled ? `${r.cancelled} annullati` : "",
        r.removed ? `${r.removed} rimossi` : "",
      ].filter(Boolean).join(" · ");

      controlli.append(bottone("Dettagli", "ghost", comando("vr:openPage", { pagina: `src/dashboard.html#coda-${coda.startedAt}` })));
      if (r.error + r.interrupted) controlli.append(bottone(`Riprova i falliti (${r.error + r.interrupted})`, "ghost", comando("vr:queueRetry", { queue: coda.startedAt })));
      controlli.append(bottone("Chiudi", "ghost", comando("vr:queueClear")));
      return;
    }

    // selezione in attesa di partire
    titolo.textContent = `${quanti} ${quanti === 1 ? "articolo selezionato" : "articoli selezionati"}`;
    sotto.textContent = descriviOpzioni();

    const v = validate();
    controlli.append(
      bottone(v.ok ? "Opzioni" : "Opzioni ⚠", "ghost", () => apriOpzioni(), { "aria-haspopup": "dialog" }),
      bottone("Tutti", "ghost", () => VR.selection.tutti()),
      bottone("Nessuno", "ghost", () => VR.selection.nessuno()),
      // Il bottone si spegne per il doppio clic e si ridisegna comunque alla fine:
      // se l'avvio si ferma (opzioni annullate, errore) non deve restare spento.
      bottone("Avvia", "primary", (e) => { e.currentTarget.disabled = true; parti().finally(disegna); }));
  }

  // ---------------------------------------------------------------- esecuzione

  /**
   * Gli articoli che QUESTA scheda sta lavorando: annullamento chiesto, punto di
   * non ritorno passato, passo attuale. E' quello che risponde alla sonda del
   * service worker ("ci stai ancora lavorando?").
   */
  const lavorazioni = new Map();
  VR.lavorazioniAttive = () => lavorazioni.size;
  VR.aggiornaPannello = () => disegna();

  /**
   * Giornale del tentativo in storage (vrOp:<id>): fase, id del nuovo annuncio,
   * esito. Se il messaggio con l'esito si perde o la pagina muore, il service
   * worker trova qui le prove. Una chiave per articolo: un solo scrittore.
   */
  const chiaveGiornale = (id) => `vrOp:${id}`;
  async function scriviGiornale(id, base, patch) {
    Object.assign(base, patch, { at: Date.now() });
    await chrome.storage.local.set({ [chiaveGiornale(id)]: { ...base } });
  }

  /**
   * Errore che ferma il tentativo PRIMA di inviare qualcosa a Vinted, con il
   * motivo vero. Fino alla 2.2 ogni no senza motivo diventava «permesso
   * negato», e un errore interno del service worker sembrava un rifiuto.
   *   annullato: l'hai chiesto tu → «Annullato»
   *   tecnico: problema dell'estensione (service worker, salvataggio, versioni)
   *     → «Interrotto», riprovabile, e la coda si mette in pausa
   *   altrimenti: il tentativo non valeva piu' (il service worker l'aveva gia'
   *     chiuso): l'esito non cambia niente
   */
  function fermato(r) {
    const e = new Error(`Fermato prima dell'invio a Vinted: ${r?.motivo || "il service worker ha rifiutato senza motivo"}. Nessun annuncio creato o eliminato.`);
    e.codice = r?.codice || "sconosciuto";
    if (r?.annullato || r?.codice === "annullato") e.annullato = true;
    else if (r?.tecnico || !r?.codice) e.tecnico = true;
    else e.superato = true;
    return e;
  }

  /**
   * Chiede il permesso al service worker. Una risposta vera (si' o no con un
   * motivo) vale subito. Nessuna risposta, una risposta vuota o un errore
   * tecnico ritentabile (salvataggio, service worker che si riavvia) si
   * riprovano qualche volta prima di arrendersi, e il motivo dice quale dei casi.
   */
  async function chiediPermesso(messaggio) {
    let ultimo = null;
    for (const attesa of [0, 600, 1500, 3000]) {
      if (attesa) await VR.sleep(attesa);
      let r;
      try {
        r = await chrome.runtime.sendMessage(messaggio);
      } catch (errore) {
        const testo = String(errore?.message || errore);
        if (/context invalidated/i.test(testo)) {
          return { ok: false, codice: "estensione-ricaricata", tecnico: true, motivo: "l'estensione è stata ricaricata o aggiornata durante il lavoro: ricarica la scheda di Vinted" };
        }
        ultimo = { ok: false, codice: "sw-irraggiungibile", tecnico: true, motivo: `il service worker non risponde (${testo.slice(0, 120)})` };
        continue;
      }
      if (r && typeof r === "object" && typeof r.ok === "boolean") {
        if (r.ok || !r.ritentabile) return r;
        ultimo = r;
        continue;
      }
      ultimo = { ok: false, codice: "risposta-vuota", tecnico: true,
        motivo: `il service worker ha risposto senza un esito (${r === undefined ? "nessun valore" : String(JSON.stringify(r)).slice(0, 60)})` };
    }
    return ultimo;
  }

  /**
   * L'esito si manda finche' il service worker non conferma di averlo ricevuto:
   * fino alla 2.1 partiva una volta sola e, se si perdeva, dopo 6 minuti
   * l'articolo diventava «da verificare» anche se era stato pubblicato.
   */
  async function consegnaEsito(messaggio) {
    for (const attesa of [0, 2000, 5000, 15000, 30000, 60000]) {
      if (attesa) await VR.sleep(attesa);
      try {
        const r = await chrome.runtime.sendMessage(messaggio);
        if (r?.ok) return true;
      } catch {
        // service worker in riavvio o estensione ricaricata: si riprova
      }
    }
    return false;
  }

  /**
   * Il service worker chiede di ripubblicare un articolo: rispondo subito e
   * riferisco l'esito a cose fatte. Passa dallo stesso blocco del bottone:
   * se l'articolo e' gia' in ripubblicazione a mano, la coda lo salta.
   */
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "vr:relistOne") return false;
    sendResponse({ accepted: true });

    const id = String(message.itemId);
    const avviatoAt = Number(message.avviatoAt) || null;
    const barra = VR.bars.get(id);
    const stato = { richiesto: false, oltre: false, passo: "Avvio…", passoAt: Date.now(), avviatoAt, fase: "preparazione" };
    lavorazioni.set(id, stato);
    const giornale = { id, avviatoAt, sessione: Number(message.sessione) || null, fase: "preparazione" };

    const riferisci = async (esito) => {
      // prima la prova in storage, poi il messaggio: se questo si perde, quella resta
      await scriviGiornale(id, giornale, { fase: "concluso", esito }).catch(() => {});
      await consegnaEsito({ type: "vr:relistDone", itemId: id, avviatoAt, ...esito });
    };

    let ultimoPasso = 0;
    const passo = (testo) => {
      passoLocale = { id, testo };
      stato.passo = testo;
      stato.passoAt = Date.now();
      barra?.stato(testo);
      const sotto = pannello?.querySelector(".vr-queue__sub");
      if (sotto) sotto.textContent = testo;
      // al popup basta un aggiornamento ogni tanto, non uno per evento
      if (Date.now() - ultimoPasso > 700 || /Fatto|Pubblico/.test(testo)) {
        ultimoPasso = Date.now();
        chrome.runtime.sendMessage({ type: "vr:queueProgress", itemId: id, step: testo, fase: stato.oltre ? "invio" : "preparazione" }).catch(() => {});
      }
    };

    const segnale = {
      annullato: () => stato.richiesto,
      // Il permesso di passare il punto di non ritorno lo da' il service worker:
      // se nel frattempo ha dato il tentativo per interrotto, o hai annullato,
      // risponde no e qui ci si ferma senza aver inviato niente.
      oltre: async (info) => {
        const r = await chiediPermesso({ type: "vr:relistConfirm", itemId: id, avviatoAt, traccia: info, build: VR.BUILD });
        if (!r?.ok) throw fermato(r);
        stato.oltre = true;
        stato.fase = "invio";
        await scriviGiornale(id, giornale, { fase: "invio", fotoIds: info?.fotoIds || [], prezzo: info?.prezzo ?? null,
          ordine: info?.ordine, eliminaVecchio: info?.eliminaVecchio });
      },
      creato: async (nuovoId) => {
        stato.fase = "creato";
        await scriviGiornale(id, giornale, { fase: "creato", nuovoId: String(nuovoId) });
      },
    };

    barra?.occupato(true);
    scriviGiornale(id, giornale, {})
      .then(() => VR.esclusivo(id, () => VR.relist(id, { ...(message.overrides || {}), ...(message.vintory ? { vintory: message.vintory } : {}) }, passo, segnale)))
      .then((creato) => {
        barra?.segnaFatto();
        return riferisci({ ok: true, nuovoId: creato?.id != null ? String(creato.id) : undefined });
      })
      .catch((e) => {
        if (e?.duplicato) return riferisci({ ok: false, outcome: "skipped", motivoSalto: "in-uso", error: "già in ripubblicazione a mano" });
        // Venduto nel frattempo: si salta questo, la coda continua con gli altri.
        if (e?.venduto) {
          barra?.stato("Venduto: saltato", "warn");
          return riferisci({ ok: false, outcome: "skipped", motivoSalto: "venduto", error: e.message, categoria: "venduto", sicuro: "no" });
        }
        // Da Vintory ma ancora online, senza la scelta «copia di Vintory»: si salta, la coda continua.
        if (e?.online) {
          barra?.stato("Ancora online: saltato", "warn");
          return riferisci({ ok: false, outcome: "skipped", motivoSalto: "online", error: e.message, categoria: "online", sicuro: "no" });
        }
        const k = CL().classificaErrore(e);
        const outcome = e?.annullato ? "cancelled" : e?.tecnico || e?.superato ? "interrupted" : VR.esitoDaErrore(e);
        barra?.stato(e?.message || String(e), outcome === "error" ? "error" : "warn");
        if (outcome === "partial") barra?.segnaFatto();
        else barra?.occupato(false);
        return riferisci({
          ok: false, outcome, error: e?.message || String(e), blocked: Boolean(e?.blocked),
          categoria: k.categoria, sicuro: k.sicuroRiprovare, nuovoId: e?.nuovoId,
        });
      })
      .finally(() => {
        lavorazioni.delete(id);
        if (passoLocale?.id === id) passoLocale = null;
      });

    return false;
  });

  /**
   * 2.5.0, «Ripubblica da Vintory»: la dashboard chiede (tramite il service
   * worker) com'e' adesso su Vinted ogni annuncio del file. Solo letture, una
   * alla volta, con una pausa: e' la stessa lettura che fa il sito.
   */
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "vr:vintoryLeggi") return false;
    const ids = (Array.isArray(message.ids) ? message.ids : []).map(String).filter((x) => /^\d{1,20}$/.test(x)).slice(0, 25);
    (async () => {
      const letture = {};
      for (const [i, id] of ids.entries()) {
        if (i) await VR.sleep(350);
        try {
          letture[id] = await VR.api.statoVintory(id);
        } catch (e) {
          letture[id] = { esito: "ignoto", motivo: e?.message || String(e) };
        }
      }
      sendResponse({ ok: true, letture, account: VR.settings.userId != null ? String(VR.settings.userId) : null });
    })();
    return true;
  });

  /** La sonda del service worker: questa scheda sta ancora lavorando l'articolo? */
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "vr:relistStatus") return false;
    const s = lavorazioni.get(String(message.itemId));
    const stesso = s && (message.avviatoAt == null || s.avviatoAt == null || Number(message.avviatoAt) === s.avviatoAt);
    sendResponse(stesso ? { inCorso: true, fase: s.fase, passo: s.passo, passoAt: s.passoAt } : { inCorso: false });
    return false;
  });

  /** Verifica di un tentativo senza esito: solo letture su Vinted, il verdetto lo da' il service worker. */
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "vr:verifyRelist") return false;
    const id = String(message.itemId || "");
    if (!/^\d{1,20}$/.test(id)) { sendResponse({ vecchio: "ignoto", nuovo: "ignoto", limiti: ["id non valido"] }); return false; }
    VR.verificaPubblicazione({
      itemId: id,
      nuovoId: /^\d{1,20}$/.test(String(message.nuovoId || "")) ? String(message.nuovoId) : null,
      fotoIds: Array.isArray(message.fotoIds) ? message.fotoIds.slice(0, 30) : [],
    })
      .then(sendResponse)
      .catch((e) => sendResponse({ vecchio: "ignoto", nuovo: "ignoto", limiti: [e?.message || String(e)] }));
    return true;
  });

  /** «Annulla operazione»: rispettato solo se la richiesta a Vinted non e' ancora partita. */
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "vr:relistCancel") return false;
    const stato = lavorazioni.get(String(message.itemId));
    if (!stato) sendResponse({ ok: false, motivo: "l'articolo non è in lavorazione in questa scheda" });
    else if (stato.oltre) sendResponse({ ok: false, troppoTardi: true });
    else {
      stato.richiesto = true;
      sendResponse({ ok: true });
    }
    return false;
  });

  /**
   * Ripristino dalla dashboard: ripubblica l'annuncio attuale con i dati di
   * prima. Non e' un annullamento letterale — l'annuncio originale e' stato
   * cancellato con le sue visite — ma rimette titolo, descrizione e prezzo.
   */
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "vr:restore") return false;

    VR.esclusivo(message.newId, () =>
      VR.relist(message.newId, message.overrides || {}, (passo) => VR.log("ripristino:", passo))
    )
      .then((creato) => sendResponse({ ok: true, id: creato?.id }))
      .catch((errore) => sendResponse({ ok: false, error: errore.message, outcome: VR.esitoDaErrore(errore) }));
    return true;
  });

  /** Il popup chiede una verifica: la facciamo sul primo articolo visibile. */
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "vr:canaryAny") return false;

    const primo = document.querySelector(".vr-bar__pick");
    if (!primo) {
      sendResponse({ ok: false, problemi: ["Apri il tuo armadio su Vinted e riprova."] });
      return false;
    }

    VR.canary(primo.dataset.vrId)
      .then((esito) => sendResponse(esito))
      .catch((errore) => sendResponse({ ok: false, problemi: [errore.message] }));
    return true;
  });

  // --------------------------------------------------------------------- stato

  // ------------------------------------------------------------ marcatori

  /**
   * Il marcatore sotto ogni card deriva SOLO dalla coda salvata (vrQueue): niente
   * stato visivo a parte che potrebbe andare fuori sincrono. Si ricalcola a ogni
   * cambio della coda e a ogni barra nuova (scroll, navigazione, ricarica).
   *   In coda / In attesa / In elaborazione / Da verificare: la casella si spegne,
   *   l'articolo non si puo' rimettere in coda ne' ripubblicare a mano.
   *   Completato / Errore / Interrotto / Annullato: solo informazione, finche' la
   *   sessione e' aperta; la casella resta attiva. Rimossi e saltati: nessun marcatore.
   */
  const BLOCCANTI = new Set(["pending", "working", "verify"]);
  function statoArticolo(id) {
    const q = CL().migra(coda);
    if (!q?.items) return null;
    const a = CL().trova(q, id);
    if (!a) return null;
    if (!q.running && a.status !== "verify") return null;
    const ora = (t) => new Date(t).toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
    let testo = null;
    switch (a.status) {
      case "pending": {
        const pos = CL().posizione(q, a.id);
        const primo = pos === 1;
        testo = q.state === "paused" ? `In coda · #${pos} · coda in pausa`
          : primo && q.nextAt && !CL().corrente(q) ? `In attesa · parte verso le ${ora(q.nextAt)}`
          : `In coda · #${pos}`;
        break;
      }
      case "working": testo = "In elaborazione"; break;
      case "verify": testo = "Da verificare: non rimetterlo in coda"; break;
      case "done": testo = "Completato"; break;
      case "error": testo = a.error ? `Errore: ${String(a.error).slice(0, 80)}` : "Errore"; break;
      case "interrupted": testo = "Interrotto"; break;
      case "cancelled": testo = "Annullato"; break;
      default: return null;                                   // rimosso, saltato: nessun marcatore
    }
    const bloccante = BLOCCANTI.has(a.status)
      ? a.status === "verify"
        ? "Esito da verificare: potrebbe essere già online. Verificalo prima di ripubblicarlo."
        : "È già nella coda ed è in attesa di ripubblicazione: non serve aggiungerlo di nuovo."
      : null;
    return { stato: a.status, testo, bloccante };
  }
  VR.statoInCoda = (id) => {
    const s = statoArticolo(String(id));
    return s?.bloccante ? s : null;
  };

  function aggiornaMarcatori() {
    for (const bar of document.querySelectorAll(".vr-bar[data-vr-bar]")) {
      const id = bar.dataset.vrBar;
      const s = statoArticolo(id);
      const mark = bar.querySelector(".vr-bar__mark");
      bar.dataset.vrStato = s?.stato || "";
      if (mark) {
        mark.hidden = !s;
        mark.textContent = s?.testo || "";
      }
      // L'avviso «è già nella coda» di un clic precedente non vale piu' quando lo stato cambia.
      const avviso = bar.querySelector(".vr-bar__status--warn");
      if (avviso && !s?.bloccante && /già nella coda|Esito da verificare/.test(avviso.textContent)) {
        avviso.className = "vr-bar__status";
        avviso.textContent = "";
      }
      const pick = bar.querySelector(".vr-bar__pick");
      if (pick) {
        pick.disabled = Boolean(s?.bloccante);
        pick.title = s?.bloccante || "Aggiungi alla coda — Shift per selezionare un intervallo";
        if (s?.bloccante && selezionati.has(id)) VR.selection.cambia(id, false);
      }
    }
  }
  VR.aggiornaMarcatori = aggiornaMarcatori;

  chrome.storage.local.get("vrQueue").then(({ vrQueue }) => {
    coda = vrQueue || null;
    disegna();
    aggiornaMarcatori();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.vrQueue) return;
    coda = changes.vrQueue.newValue || null;
    disegna();
    aggiornaMarcatori();
  });
})();
