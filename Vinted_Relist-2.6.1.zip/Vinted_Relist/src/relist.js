/* Logica di ripubblicazione. */
(() => {
  const VR = (window.VR = window.VR || {});

  /** Dimensioni di una miniatura, lette dai campi o dal nome del tipo (es. thumb624x624). */
  function thumbArea(thumb) {
    if (thumb?.width && thumb?.height) return thumb.width * thumb.height;
    const match = String(thumb?.type || "").match(/(\d+)x(\d+)/);
    return match ? Number(match[1]) * Number(match[2]) : 0;
  }

  /** L'URL alla risoluzione piu' alta disponibile: ricaricare una miniatura rovina l'annuncio. */
  function bestPhotoUrl(photo) {
    if (photo.full_size_url) return photo.full_size_url;
    if (photo.high_resolution?.url) return photo.high_resolution.url;

    const thumbnails = photo.thumbnails || [];
    if (thumbnails.length) {
      const largest = [...thumbnails].sort((a, b) => thumbArea(b) - thumbArea(a))[0];
      if (largest?.url) return largest.url;
    }
    return photo.url || photo.image_url || null;
  }

  /** Foto con l'indicazione se manca la versione a piena risoluzione. */
  function photoInfo(item) {
    const photos = item?.photos || item?.assigned_photos || [];
    return photos
      .map((photo) => ({
        url: bestPhotoUrl(photo),
        ridotta: !(photo.full_size_url || photo.high_resolution?.url),
      }))
      .filter((f) => f.url);
  }

  function photoUrls(item) {
    const photos = item?.photos || item?.assigned_photos || [];
    return photos.map(bestPhotoUrl).filter(Boolean);
  }

  const MAX_SIDE = 1600;          // Vinted non mostra nulla di piu' grande
  const MAX_BYTES = 4.5 * 1024 * 1024;

  /**
   * Geometria di una foto modificata: rotazione a passi di 90°, poi ritaglio
   * espresso in frazioni dell'immagine *gia' ruotata*, poi riduzione al lato
   * massimo. Funzione pura: e' qui che si sbaglia, quindi si testa da sola.
   */
  function geometria(larghezza, altezza, { rotate = 0, crop = null, maxSide = MAX_SIDE } = {}) {
    const r = ((Math.round(rotate / 90) * 90) % 360 + 360) % 360;
    const girata = r === 90 || r === 270;
    const W = girata ? altezza : larghezza;      // dimensioni dopo la rotazione
    const H = girata ? larghezza : altezza;

    const c = crop || { x: 0, y: 0, w: 1, h: 1 };
    const x = Math.min(Math.max(c.x, 0), 1);
    const y = Math.min(Math.max(c.y, 0), 1);
    const w = Math.min(Math.max(c.w, 0.05), 1 - x);
    const h = Math.min(Math.max(c.h, 0.05), 1 - y);

    const tagliataW = W * w;
    const tagliataH = H * h;
    const scala = Math.min(1, maxSide / Math.max(tagliataW, tagliataH));

    return {
      r,
      W,
      H,
      ox: x * W,
      oy: y * H,
      scala,
      larghezza: Math.max(1, Math.round(tagliataW * scala)),
      altezza: Math.max(1, Math.round(tagliataH * scala)),
    };
  }

  /** Disegna la foto con rotazione e ritaglio su un canvas nuovo. */
  async function renderFoto(sorgente, opzioni = {}) {
    const bitmap = sorgente instanceof Blob ? await createImageBitmap(sorgente) : sorgente;
    const g = geometria(bitmap.width, bitmap.height, opzioni);

    const canvas = document.createElement("canvas");
    canvas.width = g.larghezza;
    canvas.height = g.altezza;
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingQuality = "high";

    // spazio ruotato W×H, spostato sull'angolo del ritaglio, poi scalato
    ctx.scale(g.scala, g.scala);
    ctx.translate(-g.ox, -g.oy);
    ctx.translate(g.W / 2, g.H / 2);
    ctx.rotate((g.r * Math.PI) / 180);
    ctx.drawImage(bitmap, -bitmap.width / 2, -bitmap.height / 2);

    if (sorgente instanceof Blob) bitmap.close?.();
    return canvas;
  }

  /**
   * Vinted rifiuta i file che non riconosce come JPEG valido (il CDN restituisce WebP)
   * e quelli troppo pesanti. Ridisegnare su canvas risolve entrambe le cose, e nello
   * stesso passaggio applica rotazione e ritaglio scelti nell'editor.
   */
  async function toJpeg(blob, opzioni = {}) {
    try {
      const canvas = await renderFoto(blob, opzioni);

      for (const quality of [0.88, 0.75, 0.6]) {
        const jpeg = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", quality));
        if (jpeg && jpeg.size > 1024 && jpeg.size < MAX_BYTES) {
          VR.log(`foto ${canvas.width}×${canvas.height}, ${Math.round(jpeg.size / 1024)} KB (q${quality})`);
          return jpeg;
        }
      }
    } catch (error) {
      VR.warn("riconversione in JPEG non riuscita, uso il file originale", error);
    }
    return blob;
  }

  VR.geometria = geometria;
  VR.renderFoto = renderFoto;
  VR.photoUrls = photoUrls;
  VR.photoInfo = photoInfo;

  // ------------------------------------------------------- download delle foto

  const blobADataUrl = (blob) =>
    new Promise((ok, ko) => {
      const lettore = new FileReader();
      lettore.onload = () => ok(lettore.result);
      lettore.onerror = () => ko(lettore.error || new Error("lettura non riuscita"));
      lettore.readAsDataURL(blob);
    });

  const DA_MIME = {
    "image/jpeg": { ext: "jpg", mime: "image/jpeg" },
    "image/png": { ext: "png", mime: "image/png" },
    "image/webp": { ext: "webp", mime: "image/webp" },
    "image/gif": { ext: "gif", mime: "image/gif" },
    "image/avif": { ext: "avif", mime: "image/avif" },
  };

  /**
   * Scarica le foto scelte, due alla volta. Un errore su una foto non ferma le
   * altre: il risultato dice, foto per foto, com'e' andata.
   * `cache` e' quella dell'editor: le foto gia' scaricate per le miniature non
   * vengono richieste una seconda volta.
   */
  VR.scaricaFoto = async (itemId, voci, cache, avanzamento = () => {}) => {
    const L = VR.editorLogica;
    const usati = new Set();
    const risultati = [];
    let prossimo = 0;
    let fatte = 0;

    async function una(v) {
      try {
        const blob = cache ? await cache.carica(v.url) : await VR.api.downloadPhoto(v.url);
        const testa = new Uint8Array(await blob.slice(0, 16).arrayBuffer());
        const formato = L.formatoImmagine(testa) || DA_MIME[String(blob.type).split(";")[0]];
        if (!formato) throw new Error("formato non riconosciuto");

        const [nome] = L.nomiFoto(itemId, [{ posizione: v.posizione, ext: formato.ext }], usati);
        const dataUrl = await blobADataUrl(new Blob([blob], { type: formato.mime }));
        const r = await chrome.runtime.sendMessage({ type: "vr:download", url: dataUrl, nome });
        if (!r?.ok) throw new Error(r?.error || "download non riuscito");
        return { ok: true, posizione: v.posizione, nome: r.nome || nome };
      } catch (errore) {
        return { ok: false, posizione: v.posizione, errore: errore?.message || "errore sconosciuto" };
      }
    }

    async function lavoratore() {
      while (prossimo < voci.length) {
        const v = voci[prossimo++];
        risultati.push(await una(v));
        avanzamento(++fatte);
      }
    }

    await Promise.all([lavoratore(), lavoratore()]);
    return risultati.sort((a, b) => a.posizione - b.posizione);
  };

  /**
   * Il dizionario dei colori si riempie leggendo gli annunci. Se e' vuoto
   * (estensione appena installata), ne legge alcuni del tuo armadio: solo
   * letture, con una pausa tra l'una e l'altra.
   */
  VR.imparaColori = async (massimo = 8) => {
    const { inventory = {} } = await chrome.storage.local.get("inventory");
    const ids = Object.entries(inventory)
      .sort((a, b) => (b[1].lastSeen || 0) - (a[1].lastSeen || 0))
      .slice(0, massimo)
      .map(([id]) => id);

    for (const id of ids) {
      try {
        await VR.api.getUploadDraft(id);
      } catch {
        // articolo sparito o non leggibile: si passa al prossimo
      }
      if (Object.keys(VR.settings.colorMap || {}).length >= 8) break;
      await VR.sleep(600);
    }
    return Object.keys(VR.settings.colorMap || {}).length;
  };

  /** Riprova con pause crescenti: i fallimenti singoli qui sono quasi sempre passeggeri. */
  async function withRetry(label, run, attempts = 3) {
    let lastError = null;
    for (let attempt = 1; attempt <= attempts; attempt++) {
      try {
        return await run();
      } catch (error) {
        lastError = error;
        if (error.blocked) throw error;          // insistere su un 429 lo peggiora
        VR.warn(`${label}: tentativo ${attempt}/${attempts} fallito — ${error.message}`);
        if (attempt < attempts) await VR.sleep(800 * attempt);
      }
    }
    throw lastError;
  }

  /**
   * I campi che il POST di pubblicazione accetta davvero, letti da una richiesta
   * reale di Vinted. La lettura ne restituisce altri (brand_dto, color1_id,
   * domestic_shipment_price, photos, promoted…) che qui non vanno.
   *
   * size_id e status_id non compaiono in questo elenco perche' l'articolo
   * osservato e' da collezione: servono per l'abbigliamento e li teniamo.
   */
  const ALLOWED_FIELDS = [
    "id",
    "currency",
    "temp_uuid",
    "title",
    "description",
    "brand_id",
    "brand",
    "catalog_id",
    "isbn",
    "is_unisex",
    "ai_photo",
    "price",
    "package_size_id",
    "shipment_prices",
    "color_ids",
    "assigned_photos",
    "measurement_length",
    "measurement_width",
    "item_attributes",
    "manufacturer",
    "manufacturer_labelling",
    "size_id",
    "status_id",
  ];

  /**
   * Come si ricava ogni campo della scrittura da quelli della lettura.
   * Sono le sei differenze fra i due formati, scritte una volta sola.
   */
  const DERIVATIONS = {
    // la lettura espone brand_dto: {id, title}, la scrittura vuole nome e id separati
    brand: (src) => src.brand ?? src.brand_dto?.title ?? null,
    brand_id: (src) => src.brand_id ?? src.brand_dto?.id ?? null,

    // color1_id / color2_id → un solo array. Assente o null → [] (nessun colore);
    // un valore che non e' un id valido si scarta invece di finire nel payload.
    color_ids: (src) => idColori(src),

    // {amount: "10.0", currency_code: "EUR"} → 10 (numero, non stringa)
    price: (src) => {
      const amount = scalarAmount(src.price);
      return amount == null ? null : Number(amount);
    },
    currency: (src) => src.currency ?? src.price?.currency_code ?? "EUR",

    // la lettura tiene i due prezzi separati e shipment_prices a null,
    // la scrittura vuole sempre l'oggetto con le due chiavi
    shipment_prices: (src) => ({
      domestic: scalarAmount(src.shipment_prices?.domestic ?? src.domestic_shipment_price),
      international: scalarAmount(
        src.shipment_prices?.international ?? src.international_shipment_price
      ),
    }),
  };

  /** Gli id colore validi dell'originale (interi positivi), nell'ordine color1, color2. */
  function idColori(src) {
    return [src.color1_id, src.color2_id]
      .filter((id) => id != null && id !== "")
      .map(Number)
      .filter((id) => Number.isInteger(id) && id > 0);
  }

  /** Ricalca la forma delle voci foto osservata nella richiesta vera. */
  function buildAssignedPhotos(photoIds) {
    const template = VR.settings.itemFormat?.sample?.assigned_photos?.[0];

    if (template && typeof template === "object") {
      return photoIds.map((id, index) => {
        const entry = {};
        for (const key of Object.keys(template)) {
          if (key === "id") entry.id = id;
          else if (key === "index" || key === "position" || key === "order") entry[key] = index;
          else entry[key] = template[key];
        }
        entry.id = id;
        return entry;
      });
    }
    return photoIds.map((id) => ({ id, orientation: 0 }));
  }

  /**
   * Riempimento automatico dei campi vuoti.
   *
   * Il criterio non e' "riempi tutto": e' quanto costa sbagliare.
   *   - color_ids e is_unisex si riempiono SOLO se TUTTI gli altri tuoi articoli
   *     con lo stesso catalog_id hanno il campo (almeno 2) e concordano sul
   *     valore (maggioranza del 60%). Se la
   *     lettura non contiene il campo (libri, manga…) non ci sono prove e il
   *     campo resta com'e': assente non vuol dire obbligatorio.
   *   - package_size_id si segnala e basta: sbagliare la dimensione del pacco
   *     si paga in spedizione, quindi la scelta resta tua.
   *   - isbn, misure, manufacturer non si toccano mai: sono dati del singolo
   *     oggetto, copiarli da un altro articolo significa pubblicare il falso.
   *
   * I valori non sono inventati: vengono da cosa hai messo tu sugli altri
   * articoli della stessa categoria.
   */
  VR.CAMPI_OSSERVATI = ["color_ids", "is_unisex", "package_size_id"];

  const DA_RIEMPIRE = ["color_ids", "is_unisex"];
  const DA_SEGNALARE = ["package_size_id"];

  const ETICHETTE = {
    color_ids: "colore",
    is_unisex: "unisex",
    package_size_id: "dimensione del pacco",
  };

  const MIN_OSSERVAZIONI = 2;    // sotto, non e' un'abitudine ma un caso
  const QUORUM = 0.6;            // il valore deve essere nettamente il piu' usato

  /** Il valore di un campo ridotto a stringa, per contarlo. */
  VR.chiaveCampo = (campo, item) => {
    if (campo === "color_ids") {
      const ids = idColori(item);
      return ids.length ? ids.join(",") : null;
    }
    // false e' un valore vero e proprio ("non unisex"), non un campo vuoto
    if (typeof item[campo] === "boolean") return String(item[campo]);
    const valore = item[campo];
    return valore == null || valore === "" ? null : String(valore);
  };

  const daChiave = (campo, chiave) => {
    if (campo === "color_ids") return chiave.split(",").map(Number);
    if (campo === "is_unisex") return chiave === "true";
    return Number(chiave);
  };

  const eVuoto = (campo, valore) =>
    campo === "color_ids" ? !Array.isArray(valore) || !valore.length : valore == null;

  /**
   * L'anteprima deve vedere i campi com'erano *prima* del riempimento,
   * altrimenti non trova mai niente di vuoto da segnalare.
   */
  let senzaRiempimento = false;

  function bozzaGrezza(source, overrides) {
    senzaRiempimento = true;
    try {
      return buildDraft(source, [1], overrides);
    } finally {
      senzaRiempimento = false;
    }
  }

  /**
   * Quanti dei tuoi ALTRI articoli letti hanno lo stesso catalog_id, e quanti
   * di questi hanno un colore. Mai categorie diverse: un libro non dice niente
   * su una giacca.
   */
  VR.categoriaInfo = (catalogId, escludiId = null) => {
    let osservati = 0;
    let conColore = 0;
    for (const [id, scheda] of Object.entries(VR.settings.itemStats || {})) {
      if (String(scheda.c) !== String(catalogId)) continue;
      if (escludiId != null && String(id) === String(escludiId)) continue;
      osservati++;
      if (scheda.v?.color_ids) conColore++;
    }
    return { osservati, conColore };
  };

  /**
   * Il formato che Vinted usa per QUESTA categoria, imparato da una tua modifica
   * fatta a mano: { campi, neutri }. Dalla 2.0.1 il service worker lo salva per
   * categoria (itemFormats); per i dati precedenti si usa il formato unico solo
   * se il suo campione e' della stessa categoria. Altrimenti null: confrontare
   * un libro con il payload di una giacca produce soltanto falsi allarmi.
   */
  /** Vinted ha rifiutato perche' manca il modello? (in qualunque lingua del sito) */
  VR.chiedeModello = (e) => !e?.incerto && /\bmod(el|èle|ele|ell|elo|ello)\w*|ontology/i.test(`${e?.message || ""} ${(e?.campi || []).join(" ")}`);
  VR.CONSIGLIO_MODELLO = "Vinted chiede il modello dell'articolo. Apri l'annuncio su Vinted, «Modifica», controlla che il modello sia scelto e salva: l'estensione impara così i campi di questa categoria. Poi riprova; se non basta, manda il report diagnostico (popup › Diagnostica).";

  VR.formatoPerCategoria = (catalogId) => {
    const L = VR.editorLogica;
    const perCategoria = VR.settings.itemFormats?.[String(catalogId)];
    if (perCategoria?.campi?.length) return perCategoria;

    const unico = VR.settings.itemFormat;
    if (unico?.fields?.length && unico.sample && String(unico.sample.catalog_id) === String(catalogId)) {
      return { campi: unico.fields, neutri: unico.fields.filter((c) => L.valoreNeutro(unico.sample[c])) };
    }
    return null;
  };

  /** Il riempimento automatico e' attivo per questa operazione? Una regola sola per anteprima e invio. */
  const riempimentoAttivo = (overrides = {}) => VR.settings.autoFill !== false || overrides.autoFill === true;

  /**
   * Il valore piu' usato nella stessa categoria, se c'e' un'abitudine chiara.
   * Due condizioni, entrambe necessarie:
   *   1. il campo c'e' su TUTTI gli altri tuoi articoli letti della categoria
   *      (almeno 2): se anche uno solo e' online senza, il campo e' facoltativo
   *      e riempirlo vorrebbe dire inventare un dato;
   *   2. un valore e' nettamente il piu' usato (QUORUM).
   * L'articolo stesso non conta: altrimenti si darebbe ragione da solo.
   */
  function valorePrevalente(catalogId, campo, escludiId = null) {
    const conteggi = {};
    let totale = 0;
    let osservati = 0;

    for (const [id, scheda] of Object.entries(VR.settings.itemStats || {})) {
      if (String(scheda.c) !== String(catalogId)) continue;
      if (escludiId != null && String(id) === String(escludiId)) continue;
      osservati++;
      const chiave = scheda.v?.[campo];
      if (chiave == null) continue;
      conteggi[chiave] = (conteggi[chiave] || 0) + 1;
      totale++;
    }

    if (totale < MIN_OSSERVAZIONI || totale < osservati) return null;
    const [chiave, quanti] = Object.entries(conteggi).sort((a, b) => b[1] - a[1])[0];
    if (quanti / totale < QUORUM) return null;

    return { chiave, valore: daChiave(campo, chiave), quanti, totale };
  }

  const nomeColore = (ids) =>
    ids.map((id) => (VR.settings.colorMap || {})[id] || id).join(" e ");

  /** Cosa verrebbe riempito, e cosa resta vuoto senza che io ci metta mano. */
  VR.riempimentiPrevisti = (source, overrides = {}) => {
    const draft = bozzaGrezza(source, overrides);
    const previsti = [];
    const segnalati = [];
    const attivo = riempimentoAttivo(overrides);

    for (const campo of DA_RIEMPIRE) {
      // Stesse condizioni di buildDraft: l'anteprima non promette riempimenti
      // che la pubblicazione non farebbe (riempimento spento, campo non ammesso).
      if (!attivo || !(campo in draft) || !eVuoto(campo, draft[campo])) continue;
      const scelto = valorePrevalente(source.catalog_id, campo, source.id);
      if (!scelto) continue;
      previsti.push({
        campo,
        etichetta: ETICHETTE[campo],
        testo: campo === "color_ids" ? nomeColore(scelto.valore) : String(scelto.valore),
        quanti: scelto.quanti,
        totale: scelto.totale,
      });
    }

    for (const campo of DA_SEGNALARE) {
      if (eVuoto(campo, draft[campo])) segnalati.push(ETICHETTE[campo]);
    }

    return { previsti, segnalati };
  };

  /**
   * Punteggio di completezza dell'annuncio, da 0 a 100.
   * Misura cose verificabili sui dati, non il gusto: quante foto, quali campi
   * ci sono, quanto e' lungo il testo. Un criterio che non si applica alla
   * categoria (la taglia di un DVD) non pesa ne' a favore ne' contro.
   */
  VR.punteggio = (item) => {
    const voci = [];
    const consigli = [];
    let preso = 0;
    let possibile = 0;

    const conta = (peso, ottenuto, testo, consiglio) => {
      possibile += peso;
      preso += ottenuto;
      voci.push({ ok: ottenuto >= peso, parziale: ottenuto > 0 && ottenuto < peso, testo });
      if (ottenuto < peso && consiglio) consigli.push(consiglio);
    };

    const foto = (item.photos || []).length;
    conta(20, foto >= 5 ? 20 : foto >= 3 ? 10 : foto ? 4 : 0, `${foto} foto`,
      "Con 5 foto o piu' l'annuncio risponde a domande che altrimenti ti farebbero in chat.");

    conta(10, item.brand_id || item.brand_dto ? 10 : 0, "Marca", "Impostare la marca.");

    if ("size_id" in item) {
      conta(10, item.size_id ? 10 : 0, "Taglia", "Impostare la taglia.");
    }

    // Il colore pesa solo se l'articolo ce l'ha o se la categoria lo usa sempre:
    // a un libro senza colore non manca niente.
    const categoria = VR.categoriaInfo ? VR.categoriaInfo(item.catalog_id, item.id) : null;
    const coloreAtteso = VR.editorLogica?.statoColore([], { categoria }).livello === "avviso";
    if (idColori(item).length || coloreAtteso) {
      conta(10, idColori(item).length ? 10 : 0, "Colore",
        "Tutti gli altri tuoi articoli di questa categoria hanno un colore: aggiungilo.");
    }

    // Nelle categorie non di abbigliamento la condizione sta in item_attributes.
    const condizione = item.status_id != null || (item.item_attributes || []).length > 0;
    conta(10, condizione ? 10 : 0, "Condizione", "Indicare le condizioni dell'oggetto.");

    const descrizione = (item.description || "").trim().length;
    conta(15, descrizione >= 150 ? 15 : descrizione >= 50 ? 8 : 0,
      descrizione >= 150 ? "Descrizione completa" : "Descrizione corta",
      "Una descrizione piu' lunga — condizioni, difetti, misure — risponde prima che te lo chiedano.");

    const titolo = (item.title || "").trim();
    const parole = titolo.split(/\s+/).filter(Boolean).length;
    conta(15, titolo.length >= 25 && parole >= 4 ? 15 : titolo.length >= 12 ? 8 : 0,
      titolo.length >= 25 && parole >= 4 ? "Titolo descrittivo" : "Titolo poco descrittivo",
      "Aggiungere al titolo modello o caratteristica principale lo rende piu' trovabile.");

    conta(10, item.package_size_id ? 10 : 0, "Dimensione pacco", "Impostare la dimensione del pacco.");

    return { score: Math.round((preso / possibile) * 100), voci, consigli };
  };

  /** {amount: "10.0", currency_code: "EUR"} → "10.0" */
  function scalarAmount(value) {
    if (value == null) return null;
    if (typeof value === "object") return value.amount ?? value.value ?? null;
    return value;
  }

  /** Costruisce il payload del nuovo annuncio a partire da quello vecchio. */
  /**
   * 2.6.0 — Modello (telefoni, console, altra elettronica): Vinted lo chiede in
   * pubblicazione e lo restituisce in lettura come ontology_model_id (e
   * ontology_collection_id per le serie), a volte con un oggetto model {id, title}.
   * Prima non si copiava: «seleziona il modello» anche se l'annuncio lo aveva.
   * Si mette solo quando l'annuncio ce l'ha: per le altre categorie non cambia nulla.
   * Se una richiesta vera di Vinted (imparata) usa un altro nome con «model» o
   * «collection» dentro, riceve lo stesso id.
   */
  const intero = (v) => {
    const n = typeof v === "object" && v ? v.id : v;
    return n != null && n !== "" && Number.isInteger(Number(n)) && Number(n) > 0 ? Number(n) : null;
  };
  function campiModello(src, draft, allowed) {
    const modello = intero(src.ontology_model_id) ?? intero(src.model_id) ?? intero(src.model);
    const serie = intero(src.ontology_collection_id) ?? intero(src.collection_id) ?? intero(src.collection);
    if (modello != null) draft.ontology_model_id = modello;
    if (serie != null) draft.ontology_collection_id = serie;
    for (const campo of allowed) {
      if (campo in draft && draft[campo] != null) continue;
      if (modello != null && /model/i.test(campo) && /(^|_)id$/.test(campo)) draft[campo] = modello;
      if (serie != null && /collection/i.test(campo) && /(^|_)id$/.test(campo)) draft[campo] = serie;
    }
  }

  function buildDraft(source, photoIds, overrides = {}, tempUuid = VR.uuid()) {
    // I campi imparati da una richiesta vera si sommano ai nostri: coprono le
    // categorie che non abbiamo ancora visto senza scartare quelle note.
    // 2.6.0: anche quelli imparati per QUESTA categoria, non solo l'ultima modifica.
    const learned = [...(VR.settings.itemFormat?.fields || []), ...(VR.formatoPerCategoria?.(source.catalog_id)?.campi || [])];
    const allowed = new Set([...ALLOWED_FIELDS, ...learned]);

    const draft = {};
    for (const [key, value] of Object.entries(source)) {
      if (allowed.has(key)) draft[key] = JSON.parse(JSON.stringify(value ?? null));
    }

    for (const [key, derive] of Object.entries(DERIVATIONS)) {
      if (allowed.has(key)) draft[key] = derive(source);
    }

    campiModello(source, draft, allowed);
    draft.id = null;
    draft.temp_uuid = tempUuid;
    draft.assigned_photos = buildAssignedPhotos(photoIds);

    if (overrides.title != null) draft.title = String(overrides.title).trim();
    if (overrides.description != null) draft.description = String(overrides.description);
    // Stesso calcolo dell'anteprima nelle opzioni della coda: una sola funzione.
    draft.price = VR.editorLogica.applicaPrezzo(draft.price, overrides);

    // Colore scelto nelle opzioni della coda: solo dove manca, gli articoli che
    // ne hanno gia' uno non vanno toccati.
    if (overrides.colorIds?.length && Array.isArray(draft.color_ids) && !draft.color_ids.length) {
      draft.color_ids = overrides.colorIds.map(Number).filter((id) => !Number.isNaN(id));
    }
    if (overrides.replace?.find && VR.editorLogica) {
      const { find, with: con } = overrides.replace;
      draft.title = VR.editorLogica.sostituisci(draft.title, find, con).replace(/\s{2,}/g, " ").trim();
      draft.description = VR.editorLogica.sostituisci(draft.description, find, con);
    }
    if (overrides.descriptionAppend) {
      draft.description = `${draft.description || ""}\n${overrides.descriptionAppend}`.trim();
    }

    if (allowed.has("ai_photo") && draft.ai_photo == null) draft.ai_photo = false;

    // Per ultimo, cosi' qualunque scelta esplicita qui sopra ha la precedenza.
    if (riempimentoAttivo(overrides) && !senzaRiempimento) {
      for (const campo of DA_RIEMPIRE) {
        if (!allowed.has(campo) || !eVuoto(campo, draft[campo])) continue;

        const scelto = valorePrevalente(source.catalog_id, campo, source.id);
        if (!scelto) continue;

        draft[campo] = scelto.valore;
        VR.log(
          `${ETICHETTE[campo]} mancante: metto quello che usi su ${scelto.quanti} ` +
            `articoli su ${scelto.totale} della stessa categoria`
        );
      }
    }

    return draft;
  }

  /** Copia di sicurezza: se la creazione fallisce dopo l'eliminazione, i dati restano qui. */
  async function backup(itemId, draft) {
    const key = `vrBackup:${itemId}`;
    await chrome.storage.local.set({ [key]: { at: Date.now(), draft } });
    return key;
  }

  /**
   * Fotografia di ogni ripubblicazione: com'era prima, com'e' dopo, e
   * l'inventario che segue l'articolo sul nuovo id (e con lui il valore
   * dell'armadio, subito, articolo per articolo).
   *
   * Dalla 2.2.0 lo scrive il service worker, unico scrittore dell'inventario
   * (regole in src/armadio-logica.js). Se non risponde, la pagina applica le
   * stesse regole da sola: meglio un aggiornamento locale che nessuno.
   */
  async function registraSnapshot(oldId, source, draft, created) {
    if (!created?.id) return;
    const dati = {
      oldId: String(oldId),
      newId: String(created.id),
      vecchio: { title: source.title, description: source.description, price: Number(scalarAmount(source.price)) },
      nuovo: { title: draft.title, description: draft.description, price: draft.price },
    };
    try {
      const r = await chrome.runtime?.sendMessage?.({ type: "vr:inventarioSostituisci", ...dati });
      if (r?.ok) return;
    } catch {
      // service worker non raggiungibile: ripiego qui sotto
    }
    const A = window.ArmadioLogica;
    if (!A) return;
    const stato = await chrome.storage.local.get(["inventory", "vrSnapshots", "vrInventoryReplaced"]);
    const r = A.sostituisci(stato, dati);
    if (r.cambiato) {
      await chrome.storage.local.set({ inventory: r.inventory, vrSnapshots: r.vrSnapshots, vrInventoryReplaced: r.vrInventoryReplaced });
    }
  }

  VR.visite48 = (...a) => window.ArmadioLogica?.visite48(...a) ?? null;

  /**
   * Ripubblica un articolo.
   * @param {string|number} itemId
   * @param {object} overrides  title / description / price / deleteOld
   * @param {(step:string)=>void} onProgress
   * @param {{annullato?:()=>boolean, oltre?:(info)=>Promise|void, creato?:(id)=>Promise|void}} segnale
   *   annullato(): la coda chiede di fermarsi. Si rispetta solo PRIMA del punto
   *   di non ritorno (la prima chiamata che cambia qualcosa su Vinted: eliminare
   *   il vecchio con "elimina, poi pubblica", altrimenti creare il nuovo).
   *   oltre(info): chiamato SUBITO PRIMA di quel punto, con le foto caricate e
   *   il prezzo. In coda chiede il permesso al service worker: se lancia un
   *   errore, niente e' stato inviato e ci si ferma.
   *   creato(id): Vinted ha restituito l'id del nuovo annuncio (va annotato
   *   prima di qualunque altra cosa: e' la prova che e' stato pubblicato).
   */
  // ------------------------------------------------------------ da Vintory (2.5.0)

  const erroreVintory = (testo) => Object.assign(new Error(testo), { vintory: true });

  /** Dati dell'annuncio importato (senza foto), dal service worker che tiene l'IndexedDB. */
  async function datiVintory(chiave) {
    let r = null;
    try { r = await chrome.runtime.sendMessage({ type: "vr:vintoryDati", chiave }); } catch { r = null; }
    if (!r) throw Object.assign(new Error("Il service worker non risponde: riprova fra poco."), { tecnico: true });
    if (!r.ok) throw erroreVintory(r.error || "Dati di Vintory non disponibili: riapri il file e rimetti l'annuncio in coda.");
    return r;
  }

  /** Una foto dello ZIP di Vintory, come Blob (arriva in base64: i messaggi non portano Blob). */
  async function fotoVintory(chiave, i) {
    const r = await chrome.runtime.sendMessage({ type: "vr:vintoryFoto", chiave, i });
    if (!r?.ok) throw erroreVintory(r?.error || `Foto ${i + 1} di Vintory non disponibile.`);
    const bin = atob(r.base64);
    const b = new Uint8Array(bin.length);
    for (let k = 0; k < bin.length; k++) b[k] = bin.charCodeAt(k);
    return new Blob([b], { type: r.tipo || "image/jpeg" });
  }

  /**
   * L'annuncio da ripubblicare viene dal file di Vintory invece che da Vinted.
   * Prima di tutto, di nuovo e al momento: e' tuo, e com'e' adesso su Vinted?
   *   non esiste piu'  → si crea il nuovo, senza eliminare niente (il caso per cui c'e' Vintory);
   *   venduto          → si salta;
   *   ancora online    → solo se avevi scelto «ripubblica con la copia di Vintory», e allora
   *                      il vecchio si elimina come in una ripubblicazione normale;
   *   non chiaro       → ci si ferma senza inviare niente.
   */
  async function preparaVintory(itemId, rif, deleteOldPredefinito, onProgress) {
    const d = await datiVintory(rif.chiave);
    if (String(d.id) !== String(itemId)) throw erroreVintory("I dati di Vintory non corrispondono a questo articolo.");
    const source = d.sorgente;
    // pubblica: true → il proprietario dichiarato deve esserci ed essere l'account collegato
    VR.controllaProprieta(source, { pubblica: true });
    onProgress("Controllo su Vinted…");
    const stato = await VR.api.statoVintory(itemId);
    if (stato.esito === "venduto") VR.controllaVendibile({ is_sold: true });
    if (stato.esito === "ignoto") throw new Error(`Non riesco a capire com'è l'annuncio su Vinted: ${stato.motivo || "risposta non chiara"} Niente è stato inviato.`);
    if (stato.esito === "online" && !rif.elimina) {
      throw Object.assign(new Error("Ancora online su Vinted: usa «Ripubblica» dall'armadio (o rimettilo da Vintory con «ripubblica con la copia di Vintory»)."), { online: true });
    }
    const n = Math.min(Number(d.foto) || 0, 20);
    if (!n) throw erroreVintory("Nell'importazione da Vintory non ci sono foto.");
    return {
      source,
      deleteOld: stato.esito === "online" ? deleteOldPredefinito : false,
      scelte: Array.from({ length: n }, (_, i) => ({ vintory: i })),
      chiave: rif.chiave,
    };
  }

  async function relist(itemId, overrides = {}, onProgress = () => {}, segnale = {}) {
    const settings = VR.settings;
    let deleteOld = overrides.deleteOld ?? settings.deleteOld;
    const deleteFirst = settings.order === "clean";

    // Foto caricate e non usate restano orfane su Vinted, ma nessun annuncio
    // viene creato o eliminato: e' il motivo per cui qui annullare e' sicuro.
    const seAnnullato = async () => {
      if (!segnale.annullato?.()) return;
      await chrome.storage.local.remove(`vrBackup:${itemId}`).catch(() => {});
      const errore = new Error("Annullato prima dell'invio a Vinted: nessun annuncio creato o eliminato.");
      errore.annullato = true;
      throw errore;
    };

    onProgress("Lettura articolo…");
    let source;
    let pubblica = false;
    let scelte;
    let chiaveVintory = null;
    if (overrides.vintory) {
      const v = await preparaVintory(itemId, overrides.vintory, deleteOld, onProgress);
      ({ source, deleteOld, scelte, chiave: chiaveVintory } = v);
    } else {
      try {
        source = await VR.api.getUploadDraft(itemId);
      } catch (error) {
        VR.warn("item_upload non disponibile, uso la scheda pubblica", error);
        source = await VR.api.getItem(itemId);
        if (!source) throw error;
        pubblica = true;
      }
      VR.controllaProprieta(source, { pubblica });
      VR.controllaVendibile(source);

      // L'editor puo' riordinare, togliere, ruotare e ritagliare: arriva come elenco.
      // Senza editor, tutte le foto nell'ordine originale e senza modifiche.
      scelte = Array.isArray(overrides.photos) && overrides.photos.length
        ? overrides.photos
        : photoUrls(source).map((url) => ({ url }));
    }
    if (!scelte.length) throw new Error("Nessuna foto trovata sull'articolo.");

    await backup(itemId, source);

    // Le foto vengono caricate prima di toccare il vecchio annuncio:
    // se qualcosa va storto qui, non abbiamo ancora cancellato nulla.
    // Lo stesso temp_uuid deve legare le foto all'annuncio che creeremo dopo.
    const tempUuid = VR.uuid();
    const photoIds = [];
    for (let i = 0; i < scelte.length; i++) {
      const number = i + 1;
      const foto = scelte[i];
      await seAnnullato();
      onProgress(`Foto ${number}/${scelte.length}…`);

      try {
        const id = await withRetry(`foto ${number}`, async () => {
          const original = foto.blob
            || (foto.vintory != null ? await fotoVintory(chiaveVintory, foto.vintory) : await VR.api.downloadPhoto(foto.url));
          const jpeg = await toJpeg(original, { rotate: foto.rotate || 0, crop: foto.crop || null });
          return VR.api.uploadPhoto(jpeg, `foto-${number}.jpg`, tempUuid);
        });
        photoIds.push(id);
      } catch (error) {
        throw new Error(`Foto ${number} di ${scelte.length}: ${error.message}`);
      }

      await VR.sleep(Math.max(500, settings.delayMs / 2));
    }

    const draft = buildDraft(source, photoIds, overrides, tempUuid);
    const uploadSessionId = VR.uuid();

    // Ultimo controllo: da qui in poi la richiesta parte e non si torna indietro.
    await seAnnullato();
    try {
      await segnale.oltre?.({
        fotoIds: photoIds.map(String),
        prezzo: typeof draft.price === "number" ? draft.price : null,
        ordine: deleteFirst ? "clean" : "safe",
        eliminaVecchio: Boolean(deleteOld),
      });
    } catch (errore) {
      await chrome.storage.local.remove(`vrBackup:${itemId}`).catch(() => {});
      throw errore;
    }

    if (deleteOld && deleteFirst) {
      onProgress("Elimino il vecchio annuncio…");
      await VR.api.deleteItem(itemId);
      await VR.sleep(settings.delayMs);
    }

    onProgress("Pubblico…");
    let created;
    try {
      created = await VR.api.createItem(draft, uploadSessionId);
    } catch (error) {
      if (deleteOld && deleteFirst) {
        // Il vecchio annuncio e' gia' stato eliminato: che il nuovo esista o no,
        // i dati sono nella copia di sicurezza. I segnali dell'errore restano.
        error.message +=
          " — il vecchio annuncio era gia' stato eliminato. I dati sono salvati: li recuperi dal popup.";
      }
      if (error.incerto) {
        error.message =
          `Esito incerto: ${error.message} L'annuncio potrebbe essere stato pubblicato: ` +
          "controlla l'armadio prima di riprovare.";
      } else if (VR.chiedeModello(error)) {
        error.modello = true;
        error.message = `${error.message} — ${VR.CONSIGLIO_MODELLO}`;
      }
      throw error;
    }

    // Da qui il nuovo annuncio esiste: qualunque cosa vada storta dopo, va registrato.
    try {
      await segnale.creato?.(String(created.id));
    } catch (errore) {
      VR.warn("annotazione del nuovo annuncio non riuscita", errore);
    }
    let eliminazioneFallita = null;
    if (deleteOld && !deleteFirst) {
      await VR.sleep(settings.delayMs);
      onProgress("Elimino il vecchio annuncio…");
      try {
        await VR.api.deleteItem(itemId);
      } catch (error) {
        VR.warn("Nuovo annuncio creato ma vecchio non eliminato", error);
        eliminazioneFallita = error;
      }
    }

    await chrome.storage.local.remove(`vrBackup:${itemId}`);
    await VR.scartaBozza?.(itemId);
    await registraSnapshot(itemId, source, draft, created);

    // Registro delle ripubblicazioni: passa di qui sia il bottone singolo sia la coda.
    chrome.runtime.sendMessage({ type: "vr:relistLogged", itemId: String(itemId) }).catch(() => {});

    if (eliminazioneFallita) {
      // Pubblicato ma con il vecchio ancora online: riprovare creerebbe un terzo annuncio.
      const errore = new Error(
        "Nuovo annuncio pubblicato, ma il vecchio non è stato eliminato: rimuovilo a mano dall'armadio."
      );
      errore.parziale = true;
      errore.nuovoId = String(created.id);
      throw errore;
    }

    onProgress("Fatto");
    return created;
  }

  VR.relist = relist;

  /**
   * Prima di qualunque operazione su un annuncio: e' tuo? La lettura per la
   * pubblicazione (item_upload) Vinted la da' solo al proprietario; la scheda
   * pubblica, usata come ripiego, la da' a tutti: li' il proprietario deve
   * risultare, ed essere tu. Nel dubbio ci si ferma. Vale per il bottone, la
   * coda e il ripristino, che passano tutti da relist().
   */
  /**
   * 2.4.0: un annuncio venduto (o chiuso) non si ripubblica ne' si modifica,
   * neanche se era in coda da prima: si salta, senza fermare la coda. Lo dice
   * Vinted stesso nei dati dell'articolo, riletti al momento.
   */
  VR.controllaVendibile = (source) => {
    const chiusura = String(source?.item_closing_action ?? source?.closing_action ?? "").toLowerCase();
    const venduto = source?.is_sold === true || source?.is_closed === true || /sold|vendut/.test(chiusura) ||
      String(source?.status ?? "").toLowerCase() === "sold";
    if (venduto) {
      const e = new Error("Venduto: un annuncio venduto non si ripubblica né si modifica.");
      e.venduto = true;
      throw e;
    }
  };

  VR.controllaProprieta = (source, { pubblica = false } = {}) => {
    const me = VR.settings.userId != null ? String(VR.settings.userId) : null;
    const proprietario = source?.user_id ?? source?.user?.id ?? null;
    const diverso = proprietario != null && me && String(proprietario) !== me;
    if (diverso || (pubblica && (!me || proprietario == null))) {
      const e = new Error(diverso
        ? "Non è un tuo annuncio: Vinted Relist lavora solo sugli annunci del tuo armadio."
        : "Non riesco a confermare che l'annuncio sia tuo: per sicurezza non lo tocco. Ricarica il tuo armadio e riprova.");
      e.nonTuo = true;
      throw e;
    }
  };

  /**
   * Osservazioni per verificare un tentativo senza esito: SOLO letture.
   *   vecchio: il vecchio annuncio esiste ancora?
   *   nuovo: l'annuncio che Vinted aveva restituito (se ne conosciamo l'id) esiste?
   *   trovato: id di un annuncio recente del tuo armadio che ha una delle foto
   *     caricate in quel tentativo (gli id foto sono unici: non e' un'omonimia
   *     di titolo o di prezzo).
   * Il verdetto lo da' CodaLogica.valutaVerifica, nel service worker.
   */
  VR.verificaPubblicazione = async ({ itemId, nuovoId = null, fotoIds = [] } = {}) => {
    const limiti = [];
    const vecchio = await VR.api.stato(itemId);
    const nuovo = nuovoId ? await VR.api.stato(nuovoId) : "ignoto";
    let trovato = null;

    const cercate = new Set((fotoIds || []).map(String));
    if (!nuovoId && cercate.size) {
      const me = VR.settings.userId || null;
      if (!me) {
        limiti.push("non conosco il tuo id utente: apri il tuo armadio su Vinted");
      } else {
        try {
          const recenti = await VR.api.armadioRecenti(me);
          const fotoDi = (it) => [...(it.photos || []), it.photo].filter(Boolean).map((f) => String(f.id ?? ""));
          trovato = recenti.find((it) => String(it.id) !== String(itemId) && fotoDi(it).some((id) => cercate.has(id)))?.id ?? null;
          if (trovato != null) trovato = String(trovato);
        } catch (errore) {
          limiti.push(`non riesco a leggere gli ultimi annunci del tuo armadio (${errore.message})`);
        }
      }
    } else if (!nuovoId) {
      limiti.push("non ho le foto di quel tentativo per riconoscerlo");
    }
    return { vecchio, nuovo, trovato, limiti };
  };

  /**
   * Prova a vuoto su un articolo: legge, costruisce il payload e scarica e
   * converte la prima foto. Non carica, non crea, non cancella niente.
   * Serve a non far partire una coda di tre ore se Vinted ha cambiato qualcosa.
   */
  /**
   * Diagnosi dei campi che dipendono dalla categoria: per ognuno il valore
   * nell'originale, dopo la conversione, nel payload finale, da dove viene e
   * perche' e' (o non e') un problema. Una sola regola per editor, controllo
   * preventivo e console. Solo questi campi: niente titoli, testi o segreti.
   */
  const CAMPI_DIAGNOSTICA = ["color_ids", "is_unisex", "package_size_id"];
  // 2.6.0: il modello compare nella diagnostica solo per gli annunci che ce l'hanno (telefoni…)
  const CAMPI_MODELLO = ["ontology_model_id", "ontology_collection_id"];
  const ASSENTE = "(assente)";
  const mostra = (v) => (v === undefined ? ASSENTE : JSON.stringify(v));

  VR.diagnosiCampi = (source, overrides = {}) => {
    const L = VR.editorLogica;
    const grezza = bozzaGrezza(source, overrides);
    const finale = buildDraft(source, [1], overrides);
    const formato = VR.formatoPerCategoria(source.catalog_id);
    const categoria = VR.categoriaInfo(source.catalog_id, source.id);

    // i campi del formato della stessa categoria che a noi mancano
    const extra = (formato?.campi || []).filter((c) => !(c in finale) && !CAMPI_DIAGNOSTICA.includes(c));

    const modello = CAMPI_MODELLO.filter((c) => source[c] != null && !extra.includes(c));
    return [...CAMPI_DIAGNOSTICA, ...modello, ...extra].map((campo) => {
      const originale = campo === "color_ids"
        ? `color1_id=${mostra(source.color1_id)} color2_id=${mostra(source.color2_id)}`
        : mostra(campo in source ? source[campo] : undefined);
      const trasformato = campo in grezza ? grezza[campo] : undefined;
      const inviato = campo in finale ? finale[campo] : undefined;
      const riempito = JSON.stringify(trasformato) !== JSON.stringify(inviato);
      const daOpzioni = campo === "color_ids" && overrides.colorIds?.length && !idColori(source).length &&
        (trasformato || []).length > 0;

      const fonte = inviato === undefined ? "assente"
        : riempito ? "riempimento"
        : daOpzioni ? "opzioni della coda"
        : campo in DERIVATIONS ? "derivazione"
        : "originale";

      let esito;
      if (campo === "color_ids") {
        esito = L.statoColore(inviato, { categoria, riempito });
        if (esito.livello === "ok" && daOpzioni) esito = { livello: "ok", testo: "colore dalle opzioni della coda" };
      } else if (inviato === undefined) {
        esito = L.campoMancante(campo, formato);
      } else if (campo === "package_size_id" && inviato == null) {
        esito = { livello: "avviso", testo: "dimensione del pacco non impostata: la scelta resta a te" };
      } else if (riempito) {
        esito = { livello: "ok", testo: `${campo} preso dai tuoi articoli simili` };
      } else {
        esito = { livello: "ok", testo: inviato === null ? `${campo}: vuoto, come nell'originale` : `${campo}: conservato` };
      }

      return {
        campo,
        categoria: source.catalog_id ?? null,
        originale,
        trasformato: mostra(trasformato),
        inviato: mostra(inviato),
        fonte,
        livello: esito.livello,
        motivo: esito.testo,
      };
    });
  };

  VR.canary = async (itemId, overrides = {}, { foto: provaFoto = true } = {}) => {
    const problemi = [];
    const avvisi = [];
    const note = [];

    let source;
    try {
      source = await VR.api.getUploadDraft(itemId);
    } catch (error) {
      // 401/403/429: non e' l'articolo, e' la sessione o un blocco. Inutile insistere.
      const sessione = error.blocked || error.status === 401 || error.status === 403;
      const testo = error.status === 404 ? "articolo non trovato (forse già ripubblicato o venduto)" : `lettura articolo: ${error.message}`;
      return { ok: false, problemi: [testo], avvisi: [], sessione };
    }

    const urls = photoUrls(source);
    const draft = buildDraft(source, [1], overrides);

    // Obbligatori: bloccano. Il resto passa dalla diagnosi dei campi, che
    // distingue avvisi (differenze reali) da note (assenze legittime).
    const esito = VR.editorLogica.verificaPayload(draft, { foto: urls.length });
    problemi.push(...esito.bloccanti);
    avvisi.push(...esito.avvisi);

    // Riempimenti: non sono problemi, ma cambiano cio' che viene inviato.
    for (const voce of VR.riempimentiPrevisti(source, overrides).previsti) {
      avvisi.push(`${voce.etichetta} vuoto, metto \u00ab${voce.testo}\u00bb`);
    }

    const campi = VR.diagnosiCampi(source, overrides);
    for (const d of campi) {
      if (d.livello === "avviso") avvisi.push(d.motivo);
      else if (d.livello === "nota") note.push(d.motivo);
    }
    if (!VR.formatoPerCategoria(source.catalog_id) && VR.settings.itemFormat?.fields?.length) {
      note.push("il formato appreso viene da un'altra categoria: per confrontare questa, modifica e salva a mano un articolo della stessa categoria");
    }

    if (urls.length && provaFoto) {
      try {
        const originale = await VR.api.downloadPhoto(urls[0]);
        const jpeg = await toJpeg(originale);
        if (jpeg.size < 2048) problemi.push("la foto convertita e' sospettosamente piccola");
      } catch (error) {
        problemi.push(`foto: ${error.message}`);
      }
    }

    return { ok: problemi.length === 0, problemi, avvisi, note, campi };
  };

  /** Diagnosi dei campi dalla console: VR.diagnosi(123456) */
  VR.diagnosi = async (itemId) => {
    const source = await VR.api.getUploadDraft(itemId);
    const righe = VR.diagnosiCampi(source, {});
    console.table(righe);
    return righe;
  };

  /** Che tipo ha un valore, distinguendo null e array. */
  function typeOf(value) {
    if (value === null || value === undefined) return "null";
    if (Array.isArray(value)) return `array(${value.length})`;
    return typeof value;
  }

  /** Il payload grezzo che Vinted restituisce per l'articolo: VR.source(123456) */
  VR.source = async (itemId) => {
    const source = await VR.api.getUploadDraft(itemId);
    console.log("originale completo:", source);
    return source;
  };

  /** Il payload vero catturato da una pubblicazione o modifica fatta a mano. */
  VR.captured = async () => {
    const { itemFormat } = await chrome.storage.local.get("itemFormat");
    if (!itemFormat?.sample) {
      console.warn("Niente di catturato. Modifica un annuncio a mano su Vinted e salva.");
      return null;
    }
    console.log("payload reale di Vinted:", itemFormat.sample);
    return itemFormat;
  };

  /**
   * Confronta quello che invieremmo con quello che manda Vinted davvero:
   * VR.compare(123456)
   */
  VR.compare = async (itemId) => {
    const { itemFormat } = await chrome.storage.local.get("itemFormat");
    if (!itemFormat?.sample) {
      console.warn("Niente di catturato. Modifica un annuncio a mano su Vinted e salva.");
      return null;
    }

    const source = await VR.api.getUploadDraft(itemId);
    const draft = buildDraft(source, [111, 222], {});
    const real = itemFormat.sample;
    const stessaCategoria = String(real.catalog_id) === String(source.catalog_id);
    if (!stessaCategoria) {
      console.warn(`Il payload catturato è della categoria ${real.catalog_id}, l'articolo della ${source.catalog_id}: ` +
        "i campi che dipendono dalla categoria (unisex, taglia, colore…) qui non sono confrontabili.");
    }

    const mancanti = Object.keys(real).filter((key) => !(key in draft));
    const inPiu = Object.keys(draft).filter((key) => !(key in real));
    const tipiDiversi = Object.keys(real)
      .filter((key) => key in draft && typeOf(real[key]) !== typeOf(draft[key]))
      .map((key) => ({ campo: key, vinted: typeOf(real[key]), noi: typeOf(draft[key]) }));

    const formato = stessaCategoria ? VR.formatoPerCategoria(source.catalog_id) : null;
    const classificati = mancanti.map((campo) => ({ campo, ...VR.editorLogica.campoMancante(campo, formato) }));
    console.log("campi che Vinted manda e noi no:", mancanti);
    console.table(classificati);
    console.log("campi che mandiamo di troppo:", inPiu);
    console.table(tipiDiversi);
    console.log("nostro payload:", draft);
    console.log("payload di Vinted:", real);

    return { stessaCategoria, mancanti, classificati, inPiu, tipiDiversi, draft, real };
  };

  /**
   * Stampa il payload esatto che verrebbe inviato, senza pubblicare nulla:
   * VR.debugDraft(123456)
   */
  VR.debugDraft = async (itemId) => {
    const source = await VR.api.getUploadDraft(itemId);
    const draft = buildDraft(source, [111, 222], {});
    console.log("campi disponibili nell'originale:", Object.keys(source));
    console.log("campi che invierei:", Object.keys(draft));
    console.log(JSON.stringify(draft, null, 2));
    return draft;
  };

})();
