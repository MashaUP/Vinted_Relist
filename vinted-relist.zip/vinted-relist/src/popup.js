const DEFAULTS = {
  deleteOld: true,
  autoReload: false,
  showOnOtherProfiles: false,
  order: "safe",
  delayMs: 1200,
};

const fields = {
  deleteOld: document.getElementById("deleteOld"),
  autoReload: document.getElementById("autoReload"),
  showOnOtherProfiles: document.getElementById("showOnOtherProfiles"),
  order: document.getElementById("order"),
  delayMs: document.getElementById("delayMs"),
};

function valueOf(input) {
  if (input.type === "checkbox") return input.checked;
  if (input.type === "number") return Number(input.value);
  return input.value;
}

chrome.storage.local.get(DEFAULTS).then((settings) => {
  for (const [key, input] of Object.entries(fields)) {
    if (input.type === "checkbox") input.checked = settings[key];
    else input.value = settings[key];

    input.addEventListener("change", () => {
      chrome.storage.local.set({ [key]: valueOf(input) });
    });
  }
});

document.getElementById("tutorial").addEventListener("click", async () => {
  await chrome.storage.local.set({ seenOnboarding: false });
  window.close();
});

// --------------------------------------------------------------- recupero

let backupEntries = [];

async function loadBackups() {
  const everything = await chrome.storage.local.get(null);
  backupEntries = Object.entries(everything).filter(([key]) => key.startsWith("vrBackup:"));

  const container = document.getElementById("backups");
  container.textContent = "";

  if (!backupEntries.length) {
    container.textContent = "Nessuna bozza in sospeso.";
    return;
  }

  for (const [key, value] of backupEntries) {
    const row = document.createElement("div");
    const when = new Date(value.at).toLocaleString("it-IT");
    row.textContent = `${value.draft?.title || key.split(":")[1]} — ${when}`;
    container.append(row);
  }
}

document.getElementById("copy").addEventListener("click", async () => {
  if (!backupEntries.length) return;
  await navigator.clipboard.writeText(JSON.stringify(Object.fromEntries(backupEntries), null, 2));
  const button = document.getElementById("copy");
  button.textContent = "Copiato";
  setTimeout(() => (button.textContent = "Copia le bozze salvate"), 1500);
});

loadBackups();
